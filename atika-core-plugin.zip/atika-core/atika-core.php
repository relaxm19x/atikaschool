<?php
/**
 * Plugin Name:       منصة إنجازات عاتكة
 * Description:       نظام رئيسات الأقسام لمدرسة عاتكة بنت عبدالمطلب: تسجيل مع توثيق البريد، اعتماد الإدارة، لوحة تحكم خاصة بكل مادة، ونشر إنجازات المعلمات بالصور.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Add More Q8
 * Text Domain:       atika-core
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'ATIKA_VERSION', '1.0.0' );
define( 'ATIKA_FILE', __FILE__ );
define( 'ATIKA_DIR', plugin_dir_path( __FILE__ ) );
define( 'ATIKA_URL', plugin_dir_url( __FILE__ ) );

define( 'ATIKA_CPT', 'atika_achievement' );
define( 'ATIKA_TAX_SECTION', 'atika_section' );
define( 'ATIKA_TAX_SUBJECT', 'atika_subject' );
define( 'ATIKA_ROLE', 'dept_head' );

require_once ATIKA_DIR . 'includes/helpers.php';
require_once ATIKA_DIR . 'includes/cpt.php';
require_once ATIKA_DIR . 'includes/mail.php';
require_once ATIKA_DIR . 'includes/auth.php';
require_once ATIKA_DIR . 'includes/dashboard.php';
require_once ATIKA_DIR . 'includes/admin.php';

register_activation_hook( __FILE__, 'atika_activate' );
register_deactivation_hook( __FILE__, 'atika_deactivate' );

function atika_activate() {
	atika_register_role();
	atika_register_content_types();
	atika_seed_sections();
	atika_create_pages();

	if ( false === get_option( 'atika_settings' ) ) {
		add_option( 'atika_settings', atika_default_settings() );
	}
	if ( ! wp_next_scheduled( 'atika_cleanup_unverified' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'atika_cleanup_unverified' );
	}
	flush_rewrite_rules();
}

function atika_deactivate() {
	wp_clear_scheduled_hook( 'atika_cleanup_unverified' );
	flush_rewrite_rules();
}

/**
 * Role for department heads. They get no editing capability inside wp-admin;
 * everything they do goes through the front-end dashboard, which checks
 * ownership of every achievement itself.
 */
function atika_register_role() {
	if ( ! get_role( ATIKA_ROLE ) ) {
		add_role( ATIKA_ROLE, 'رئيسة قسم', array( 'read' => true, 'upload_files' => true ) );
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( atika_cpt_caps() as $cap ) {
			$admin->add_cap( $cap );
		}
	}
}

/** Pages the system needs. Created once and remembered by ID. */
function atika_create_pages() {
	$pages = array(
		'register'  => array( 'تسجيل رئيسة قسم', 'head-register', '[atika_register]' ),
		'login'     => array( 'دخول رئيسات الأقسام', 'head-login', '[atika_login]' ),
		'dashboard' => array( 'لوحة التحكم', 'head-dashboard', '[atika_dashboard]' ),
	);
	$ids = get_option( 'atika_pages', array() );
	foreach ( $pages as $key => $p ) {
		if ( ! empty( $ids[ $key ] ) && get_post( $ids[ $key ] ) ) {
			continue;
		}
		$ids[ $key ] = wp_insert_post( array(
			'post_title'   => $p[0],
			'post_name'    => $p[1],
			'post_content' => $p[2],
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'comment_status' => 'closed',
		) );
	}
	update_option( 'atika_pages', $ids );
}

add_action( 'init', 'atika_maybe_upgrade', 20 );
function atika_maybe_upgrade() {
	if ( get_option( 'atika_db_version' ) !== ATIKA_VERSION ) {
		atika_register_role();
		update_option( 'atika_db_version', ATIKA_VERSION );
	}
}
