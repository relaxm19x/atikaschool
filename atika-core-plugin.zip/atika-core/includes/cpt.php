<?php
defined( 'ABSPATH' ) || exit;

function atika_cpt_caps() {
	return array(
		'edit_atika_achievement', 'read_atika_achievement', 'delete_atika_achievement',
		'edit_atika_achievements', 'edit_others_atika_achievements', 'publish_atika_achievements',
		'read_private_atika_achievements', 'delete_atika_achievements', 'delete_private_atika_achievements',
		'delete_published_atika_achievements', 'delete_others_atika_achievements',
		'edit_private_atika_achievements', 'edit_published_atika_achievements',
	);
}

add_action( 'init', 'atika_register_content_types', 5 );
function atika_register_content_types() {
	register_post_type( ATIKA_CPT, array(
		'labels' => array(
			'name'          => 'الإنجازات',
			'singular_name' => 'إنجاز',
			'add_new'       => 'إضافة إنجاز',
			'add_new_item'  => 'إضافة إنجاز جديد',
			'edit_item'     => 'تعديل الإنجاز',
			'all_items'     => 'كل الإنجازات',
			'search_items'  => 'بحث في الإنجازات',
			'not_found'     => 'لا توجد إنجازات',
			'menu_name'     => 'الإنجازات',
		),
		'public'          => true,
		'has_archive'     => 'achievements',
		'rewrite'         => array( 'slug' => 'achievements', 'with_front' => false ),
		'menu_icon'       => 'dashicons-awards',
		'menu_position'   => 5,
		'supports'        => array( 'title', 'editor', 'thumbnail', 'author' ),
		'show_in_rest'    => false,
		'capability_type' => array( 'atika_achievement', 'atika_achievements' ),
		'map_meta_cap'    => true,
	) );

	register_taxonomy( ATIKA_TAX_SECTION, ATIKA_CPT, array(
		'labels' => array(
			'name'          => 'محاور الإنجاز',
			'singular_name' => 'محور',
			'add_new_item'  => 'إضافة محور',
			'edit_item'     => 'تعديل المحور',
			'menu_name'     => 'المحاور',
		),
		'public'            => true,
		'hierarchical'      => true,
		'show_admin_column' => true,
		'query_var'         => 'section',
		'rewrite'           => array( 'slug' => 'section', 'with_front' => false ),
		'capabilities'      => array(
			'manage_terms' => 'manage_options',
			'edit_terms'   => 'manage_options',
			'delete_terms' => 'manage_options',
			'assign_terms' => 'edit_atika_achievements',
		),
	) );

	register_taxonomy( ATIKA_TAX_SUBJECT, ATIKA_CPT, array(
		'labels' => array(
			'name'          => 'المواد الدراسية',
			'singular_name' => 'مادة',
			'edit_item'     => 'تعديل المادة',
			'menu_name'     => 'المواد',
		),
		'public'            => true,
		'hierarchical'      => false,
		'show_admin_column' => true,
		'meta_box_cb'       => 'post_categories_meta_box',
		'query_var'         => 'subject',
		'rewrite'           => array( 'slug' => 'subject', 'with_front' => false ),
		'capabilities'      => array(
			'manage_terms' => 'manage_options',
			'edit_terms'   => 'manage_options',
			'delete_terms' => 'manage_options',
			'assign_terms' => 'edit_atika_achievements',
		),
	) );

	register_post_meta( ATIKA_CPT, 'atika_teacher', array( 'type' => 'string', 'single' => true, 'sanitize_callback' => 'sanitize_text_field' ) );
	register_post_meta( ATIKA_CPT, 'atika_gallery', array( 'type' => 'array', 'single' => true ) );
}

/** The five axes the school asked for. Admin can add or rename them later. */
function atika_seed_sections() {
	$sections = array(
		'activity' => array( 'النشاط المدرسي', 'الرحلات والمسابقات والفعاليات', '#037b3e' ),
		'values'   => array( 'تفعيل القيم', 'برامج غرس القيم والسلوك', '#7a2934' ),
		'radio'    => array( 'الإذاعة المدرسية', 'فقرات الطابور الصباحي', '#1b2242' ),
		'growth'   => array( 'إنماء مهني', 'الورش والدورات التدريبية', '#575757' ),
		'lessons'  => array( 'دروس ريادية ونموذجية', 'دروس مميزة وتطبيقات صفية', '#a0650b' ),
	);
	$order = 1;
	foreach ( $sections as $slug => $s ) {
		$t = term_exists( $slug, ATIKA_TAX_SECTION );
		if ( ! $t ) {
			$t = wp_insert_term( $s[0], ATIKA_TAX_SECTION, array( 'slug' => $slug, 'description' => $s[1] ) );
		}
		if ( ! is_wp_error( $t ) ) {
			$tid = (int) ( is_array( $t ) ? $t['term_id'] : $t );
			if ( ! get_term_meta( $tid, 'atika_color', true ) ) {
				update_term_meta( $tid, 'atika_color', $s[2] );
			}
			if ( ! get_term_meta( $tid, 'atika_icon', true ) ) {
				update_term_meta( $tid, 'atika_icon', $slug );
			}
			update_term_meta( $tid, 'atika_order', $order++ );
		}
	}
}

function atika_get_sections() {
	$terms = get_terms( array(
		'taxonomy'   => ATIKA_TAX_SECTION,
		'hide_empty' => false,
		'meta_key'   => 'atika_order',
		'orderby'    => 'meta_value_num',
		'order'      => 'ASC',
	) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	// Terms without an order value (added later by admin) are skipped by meta_key ordering; add them at the end.
	$all = get_terms( array( 'taxonomy' => ATIKA_TAX_SECTION, 'hide_empty' => false ) );
	$ids = wp_list_pluck( $terms, 'term_id' );
	foreach ( (array) $all as $t ) {
		if ( ! in_array( $t->term_id, $ids, true ) ) {
			$terms[] = $t;
		}
	}
	return $terms;
}

function atika_section_color( $term ) {
	$c = $term ? get_term_meta( $term->term_id, 'atika_color', true ) : '';
	return sanitize_hex_color( $c ) ? $c : '#1b2242';
}

/** Gallery image IDs for an achievement, cover first. */
function atika_gallery_ids( $post_id ) {
	$ids = get_post_meta( $post_id, 'atika_gallery', true );
	$ids = is_array( $ids ) ? array_values( array_filter( array_map( 'intval', $ids ) ) ) : array();
	$thumb = (int) get_post_thumbnail_id( $post_id );
	if ( $thumb ) {
		$ids = array_values( array_diff( $ids, array( $thumb ) ) );
		array_unshift( $ids, $thumb );
	}
	return $ids;
}

/* ---------- Admin term meta: section color ---------- */

add_action( ATIKA_TAX_SECTION . '_edit_form_fields', function ( $term ) {
	$c = atika_section_color( $term );
	?>
	<tr class="form-field">
		<th scope="row"><label for="atika_color">لون المحور</label></th>
		<td><input type="color" name="atika_color" id="atika_color" value="<?php echo esc_attr( $c ); ?>">
		<p class="description">يظهر في بطاقات الصفحة الرئيسية وشارات الإنجازات.</p></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="atika_order">الترتيب</label></th>
		<td><input type="number" name="atika_order" id="atika_order" value="<?php echo esc_attr( (int) get_term_meta( $term->term_id, 'atika_order', true ) ); ?>" min="0" style="width:90px"></td>
	</tr>
	<?php
} );
add_action( ATIKA_TAX_SECTION . '_add_form_fields', function () {
	?>
	<div class="form-field"><label for="atika_color">لون المحور</label><input type="color" name="atika_color" id="atika_color" value="#1b2242"></div>
	<?php
} );
foreach ( array( 'created_' . ATIKA_TAX_SECTION, 'edited_' . ATIKA_TAX_SECTION ) as $hook ) {
	add_action( $hook, function ( $term_id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification -- core term screens verify their own nonce.
		if ( isset( $_POST['atika_color'] ) ) {
			$c = sanitize_hex_color( wp_unslash( $_POST['atika_color'] ) );
			if ( $c ) {
				update_term_meta( $term_id, 'atika_color', $c );
			}
		}
		if ( isset( $_POST['atika_order'] ) ) {
			update_term_meta( $term_id, 'atika_order', absint( $_POST['atika_order'] ) );
		} elseif ( '' === get_term_meta( $term_id, 'atika_order', true ) ) {
			update_term_meta( $term_id, 'atika_order', 99 );
		}
	} );
}

/* ---------- Admin list columns ---------- */

add_filter( 'manage_' . ATIKA_CPT . '_posts_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		if ( 'title' === $k ) {
			$new['atika_thumb'] = '';
		}
		$new[ $k ] = $v;
		if ( 'title' === $k ) {
			$new['atika_teacher'] = 'المعلمة';
		}
	}
	$new['author'] = 'رئيسة القسم';
	return $new;
} );
add_action( 'manage_' . ATIKA_CPT . '_posts_custom_column', function ( $col, $post_id ) {
	if ( 'atika_teacher' === $col ) {
		echo esc_html( get_post_meta( $post_id, 'atika_teacher', true ) );
	} elseif ( 'atika_thumb' === $col ) {
		$ids = atika_gallery_ids( $post_id );
		if ( $ids ) {
			echo wp_get_attachment_image( $ids[0], array( 48, 48 ), false, array( 'style' => 'border-radius:6px;object-fit:cover;width:48px;height:48px' ) );
		}
	}
}, 10, 2 );
add_action( 'admin_head', function () {
	echo '<style>.column-atika_thumb{width:56px}</style>';
} );

/* ---------- Search param on archives: ?q= ---------- */

add_filter( 'query_vars', function ( $v ) {
	$v[] = 'q';
	return $v;
} );
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_post_type_archive( ATIKA_CPT ) || $q->is_tax( array( ATIKA_TAX_SECTION, ATIKA_TAX_SUBJECT ) ) ) {
		$q->set( 'post_type', ATIKA_CPT );
		$q->set( 'posts_per_page', 12 );
		$term = get_query_var( 'q' );
		if ( $term ) {
			$q->set( 's', sanitize_text_field( $term ) );
		}
	}
} );

/** Search also matches the teacher's name. */
add_filter( 'posts_search', function ( $search, $q ) {
	global $wpdb;
	if ( is_admin() || ! $q->is_main_query() || '' === $search || ATIKA_CPT !== $q->get( 'post_type' ) ) {
		return $search;
	}
	$term = $q->get( 's' );
	$like = '%' . $wpdb->esc_like( $term ) . '%';
	$meta = $wpdb->prepare( "{$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'atika_teacher' AND meta_value LIKE %s)", $like );
	return preg_replace( '/^\s*AND\s*\(/', ' AND (' . $meta . ' OR ', $search, 1 );
}, 10, 2 );

/* ---------- Cleanup: delete images with their achievement ---------- */

add_action( 'before_delete_post', function ( $post_id ) {
	if ( ATIKA_CPT !== get_post_type( $post_id ) ) {
		return;
	}
	foreach ( atika_gallery_ids( $post_id ) as $aid ) {
		if ( (int) get_post_field( 'post_parent', $aid ) === (int) $post_id ) {
			wp_delete_attachment( $aid, true );
		}
	}
} );

/* When a head account is deleted, keep her achievements (re-owned by the deleting admin) and free the subject. */
add_action( 'delete_user', function ( $user_id ) {
	$tid = atika_head_subject_id( $user_id );
	if ( $tid ) {
		delete_term_meta( $tid, 'atika_head' );
	}
} );
