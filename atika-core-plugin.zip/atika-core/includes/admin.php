<?php
defined( 'ABSPATH' ) || exit;

/* ======================================================================
 * Admin menu: department heads + settings
 * ==================================================================== */

function atika_pending_count() {
	return count( get_users( array( 'role' => ATIKA_ROLE, 'meta_key' => 'atika_status', 'meta_value' => ATIKA_STATUS_PENDING, 'fields' => 'ID' ) ) );
}

add_action( 'admin_menu', function () {
	$n     = atika_pending_count();
	$badge = $n ? ' <span class="awaiting-mod count-' . $n . '"><span class="pending-count">' . $n . '</span></span>' : '';
	add_menu_page( 'رئيسات الأقسام', 'رئيسات الأقسام' . $badge, 'manage_options', 'atika-heads', 'atika_admin_heads_page', 'dashicons-groups', 4 );
	add_submenu_page( 'atika-heads', 'رئيسات الأقسام', 'كل الحسابات', 'manage_options', 'atika-heads', 'atika_admin_heads_page' );
	add_submenu_page( 'atika-heads', 'إعدادات المنصة', 'الإعدادات', 'manage_options', 'atika-settings', 'atika_admin_settings_page' );
} );

/* ---------------- Actions ---------------- */

add_action( 'admin_post_atika_head', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'غير مصرح.', 403 );
	}
	$uid = isset( $_REQUEST['uid'] ) ? absint( $_REQUEST['uid'] ) : 0;
	$do  = isset( $_REQUEST['do'] ) ? sanitize_key( $_REQUEST['do'] ) : '';
	check_admin_referer( 'atika_head_' . $do . '_' . $uid );
	$user = get_userdata( $uid );
	if ( ! $user || ! atika_is_head( $user ) ) {
		wp_die( 'الحساب غير موجود.' );
	}
	$msg = '';
	switch ( $do ) {
		case 'approve':
			if ( atika_subject_taken_by( atika_head_subject_name( $uid ), $uid ) && ! atika_head_subject_id( $uid ) ) {
				// Another active head holds this subject name already.
				$msg = 'conflict';
				break;
			}
			atika_activate_head( $uid, true );
			$msg = 'approved';
			break;
		case 'suspend':
			update_user_meta( $uid, 'atika_status', ATIKA_STATUS_SUSPENDED );
			WP_Session_Tokens::get_instance( $uid )->destroy_all();
			$msg = 'suspended';
			break;
		case 'resend':
			atika_send_verification( $uid );
			$msg = 'resent';
			break;
		case 'verify':
			// Admin marks the email as verified manually (e.g. email lost in spam).
			delete_user_meta( $uid, 'atika_verify_hash' );
			update_user_meta( $uid, 'atika_email_verified', current_time( 'mysql' ) );
			atika_activate_head( $uid, true );
			$msg = 'approved';
			break;
		case 'delete':
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $uid, get_current_user_id() );
			$msg = 'deleted';
			break;
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'atika-heads', 'msg' => $msg ), admin_url( 'admin.php' ) ) );
	exit;
} );

function atika_head_action_url( $do, $uid ) {
	return wp_nonce_url( admin_url( 'admin-post.php?action=atika_head&do=' . $do . '&uid=' . $uid ), 'atika_head_' . $do . '_' . $uid );
}

/* ---------------- Heads page ---------------- */

function atika_admin_heads_page() {
	$labels = atika_status_labels();
	$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : '';
	$args   = array( 'role' => ATIKA_ROLE, 'orderby' => 'registered', 'order' => 'DESC' );
	if ( $status && isset( $labels[ $status ] ) ) {
		$args['meta_key']   = 'atika_status';
		$args['meta_value'] = $status;
	}
	$heads  = get_users( $args );
	$counts = array( '' => count( get_users( array( 'role' => ATIKA_ROLE, 'fields' => 'ID' ) ) ) );
	foreach ( $labels as $k => $l ) {
		$counts[ $k ] = count( get_users( array( 'role' => ATIKA_ROLE, 'meta_key' => 'atika_status', 'meta_value' => $k, 'fields' => 'ID' ) ) );
	}
	$msgs = array(
		'approved'  => 'تم اعتماد الحساب وإرسال رسالة للرئيسة.',
		'suspended' => 'تم إيقاف الحساب وتسجيل خروجها من كل الأجهزة.',
		'resent'    => 'تم إرسال رسالة توثيق جديدة.',
		'deleted'   => 'تم حذف الحساب. إنجازاتها نُقلت إلى حسابك وبقيت منشورة، والمادة أصبحت متاحة لرئيسة جديدة.',
		'conflict'  => 'لا يمكن الاعتماد: اسم المادة نفسه مسجّل لرئيسة قسم أخرى مفعّلة. عدّلي اسم المادة من ملفها أولاً.',
	);
	$colors = array( 'unverified' => '#8a8f9e', 'pending' => '#b26a00', 'active' => '#037b3e', 'suspended' => '#7a2934' );
	?>
	<div class="wrap atika-admin">
		<h1 class="wp-heading-inline">رئيسات الأقسام</h1>
		<a href="<?php echo esc_url( atika_page_url( 'register' ) ); ?>" class="page-title-action" target="_blank">رابط صفحة التسجيل</a>
		<hr class="wp-header-end">
		<?php if ( isset( $_GET['msg'], $msgs[ $_GET['msg'] ] ) ) : ?>
			<div class="notice notice-<?php echo 'conflict' === $_GET['msg'] ? 'error' : 'success'; ?> is-dismissible"><p><?php echo esc_html( $msgs[ sanitize_key( $_GET['msg'] ) ] ); ?></p></div>
		<?php endif; ?>

		<ul class="subsubsub">
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=atika-heads' ) ); ?>" class="<?php echo '' === $status ? 'current' : ''; ?>">الكل <span class="count">(<?php echo (int) $counts['']; ?>)</span></a> |</li>
			<?php $i = 0; foreach ( $labels as $k => $l ) : $i++; ?>
				<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=atika-heads&status=' . $k ) ); ?>" class="<?php echo $status === $k ? 'current' : ''; ?>"><?php echo esc_html( $l ); ?> <span class="count">(<?php echo (int) $counts[ $k ]; ?>)</span></a><?php echo $i < count( $labels ) ? ' |' : ''; ?></li>
			<?php endforeach; ?>
		</ul>

		<table class="wp-list-table widefat fixed striped">
			<thead><tr><th style="width:22%">الاسم</th><th>المادة</th><th>البريد / الجوال</th><th style="width:120px">الحالة</th><th style="width:80px">الإنجازات</th><th style="width:110px">التسجيل</th><th style="width:230px">إجراءات</th></tr></thead>
			<tbody>
			<?php if ( ! $heads ) : ?>
				<tr><td colspan="7">لا توجد حسابات في هذه القائمة. شاركي رابط صفحة التسجيل مع رئيسات الأقسام.</td></tr>
			<?php endif; ?>
			<?php foreach ( $heads as $h ) :
				$st   = atika_head_status( $h->ID );
				$tid  = atika_head_subject_id( $h->ID );
				$n    = count_user_posts( $h->ID, ATIKA_CPT, true );
				?>
				<tr>
					<td><strong><?php echo esc_html( $h->display_name ); ?></strong><div class="row-actions"><a href="<?php echo esc_url( get_edit_user_link( $h->ID ) ); ?>">الملف الشخصي</a></div></td>
					<td><?php echo esc_html( atika_head_subject_name( $h->ID ) ); ?>
						<?php if ( $tid ) : ?><div class="row-actions"><a href="<?php echo esc_url( get_term_link( $tid, ATIKA_TAX_SUBJECT ) ); ?>" target="_blank">صفحة المادة</a></div><?php endif; ?></td>
					<td dir="ltr" style="text-align:right"><?php echo esc_html( $h->user_email ); ?><br><span style="color:#777"><?php echo esc_html( get_user_meta( $h->ID, 'atika_phone', true ) ); ?></span></td>
					<td><span style="display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;color:#fff;background:<?php echo esc_attr( $colors[ $st ] ); ?>"><?php echo esc_html( $labels[ $st ] ); ?></span></td>
					<td><?php echo $n ? '<a href="' . esc_url( admin_url( 'edit.php?post_type=' . ATIKA_CPT . '&author=' . $h->ID ) ) . '">' . (int) $n . '</a>' : '0'; ?></td>
					<td><?php echo esc_html( date_i18n( 'j M Y', strtotime( $h->user_registered ) ) ); ?></td>
					<td class="atika-actions">
						<?php if ( ATIKA_STATUS_PENDING === $st || ATIKA_STATUS_SUSPENDED === $st ) : ?>
							<a class="button button-primary" href="<?php echo esc_url( atika_head_action_url( 'approve', $h->ID ) ); ?>"><?php echo ATIKA_STATUS_SUSPENDED === $st ? 'إعادة تفعيل' : 'اعتماد'; ?></a>
						<?php endif; ?>
						<?php if ( ATIKA_STATUS_UNVERIFIED === $st ) : ?>
							<a class="button" href="<?php echo esc_url( atika_head_action_url( 'resend', $h->ID ) ); ?>">إعادة إرسال التوثيق</a>
							<a class="button" href="<?php echo esc_url( atika_head_action_url( 'verify', $h->ID ) ); ?>" onclick="return confirm('تفعيل الحساب دون توثيق البريد؟ استخدميها فقط إذا تأكدتِ من هوية الرئيسة.')">تفعيل يدوي</a>
						<?php endif; ?>
						<?php if ( ATIKA_STATUS_ACTIVE === $st ) : ?>
							<a class="button" href="<?php echo esc_url( atika_head_action_url( 'suspend', $h->ID ) ); ?>" onclick="return confirm('إيقاف حساب <?php echo esc_js( $h->display_name ); ?>؟ لن تستطيع الدخول، وتبقى إنجازاتها منشورة.')">إيقاف</a>
						<?php endif; ?>
						<a class="button atika-del" href="<?php echo esc_url( atika_head_action_url( 'delete', $h->ID ) ); ?>" onclick="return confirm('حذف حساب <?php echo esc_js( $h->display_name ); ?> نهائياً؟ إنجازاتها تبقى منشورة وتنتقل لحسابك.')">حذف</a>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description" style="margin-top:14px">كل رئيسة قسم ترى وتدير إنجازات مادتها فقط. تصميم الموقع والصفحة الرئيسية من <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>">المظهر ← تخصيص</a>، وهو متاح لمديرة الموقع فقط.</p>
	</div>
	<style>.atika-admin .atika-actions .button{margin:0 0 4px 4px}.atika-admin .atika-del{color:#7a2934;border-color:#d9b3b8}</style>
	<?php
}

/* ---------------- Settings page ---------------- */

add_action( 'admin_init', function () {
	register_setting( 'atika_settings', 'atika_settings', array(
		'sanitize_callback' => function ( $in ) {
			$d = atika_default_settings();
			return array(
				'require_approval' => empty( $in['require_approval'] ) ? 0 : 1,
				'notify_email'     => is_email( isset( $in['notify_email'] ) ? $in['notify_email'] : '' ) ? sanitize_email( $in['notify_email'] ) : $d['notify_email'],
				'max_images'       => min( 30, max( 1, absint( isset( $in['max_images'] ) ? $in['max_images'] : $d['max_images'] ) ) ),
				'max_image_mb'     => min( 20, max( 1, absint( isset( $in['max_image_mb'] ) ? $in['max_image_mb'] : $d['max_image_mb'] ) ) ),
				'token_hours'      => min( 168, max( 1, absint( isset( $in['token_hours'] ) ? $in['token_hours'] : $d['token_hours'] ) ) ),
				'cleanup_days'     => min( 60, max( 1, absint( isset( $in['cleanup_days'] ) ? $in['cleanup_days'] : $d['cleanup_days'] ) ) ),
			);
		},
	) );
} );

function atika_admin_settings_page() {
	$s = wp_parse_args( (array) get_option( 'atika_settings', array() ), atika_default_settings() );
	$server_mb = (int) floor( wp_max_upload_size() / MB_IN_BYTES );
	?>
	<div class="wrap">
		<h1>إعدادات المنصة</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'atika_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row">اعتماد الإدارة</th><td><label><input type="checkbox" name="atika_settings[require_approval]" value="1" <?php checked( $s['require_approval'], 1 ); ?>> بعد توثيق البريد، لا يُفعّل الحساب حتى تعتمده الإدارة</label>
					<p class="description">يُنصح بإبقائه مفعّلاً حتى لا تستطيع أي شخص التسجيل باسم رئيسة قسم.</p></td></tr>
				<tr><th scope="row"><label for="atika-ne">بريد التنبيهات</label></th><td><input type="email" id="atika-ne" class="regular-text" dir="ltr" name="atika_settings[notify_email]" value="<?php echo esc_attr( $s['notify_email'] ); ?>"><p class="description">تصله رسالة عند كل طلب تسجيل جديد ينتظر الاعتماد.</p></td></tr>
				<tr><th scope="row"><label for="atika-mi">أقصى عدد صور للإنجاز</label></th><td><input type="number" id="atika-mi" min="1" max="30" name="atika_settings[max_images]" value="<?php echo esc_attr( $s['max_images'] ); ?>" style="width:80px"></td></tr>
				<tr><th scope="row"><label for="atika-mb">أقصى حجم للصورة (ميغابايت)</label></th><td><input type="number" id="atika-mb" min="1" max="20" name="atika_settings[max_image_mb]" value="<?php echo esc_attr( $s['max_image_mb'] ); ?>" style="width:80px">
					<p class="description">حد الاستضافة الحالي: <?php echo (int) $server_mb; ?> ميغابايت لكل ملف.</p></td></tr>
				<tr><th scope="row"><label for="atika-th">صلاحية رابط التوثيق (ساعات)</label></th><td><input type="number" id="atika-th" min="1" max="168" name="atika_settings[token_hours]" value="<?php echo esc_attr( $s['token_hours'] ); ?>" style="width:80px"></td></tr>
				<tr><th scope="row"><label for="atika-cd">حذف الحسابات غير الموثقة بعد (أيام)</label></th><td><input type="number" id="atika-cd" min="1" max="60" name="atika_settings[cleanup_days]" value="<?php echo esc_attr( $s['cleanup_days'] ); ?>" style="width:80px"></td></tr>
			</table>
			<?php submit_button( 'حفظ الإعدادات' ); ?>
		</form>
		<h2>صفحات النظام</h2>
		<ul>
			<li>تسجيل رئيسة قسم: <a href="<?php echo esc_url( atika_page_url( 'register' ) ); ?>" target="_blank"><?php echo esc_html( atika_page_url( 'register' ) ); ?></a></li>
			<li>الدخول: <a href="<?php echo esc_url( atika_page_url( 'login' ) ); ?>" target="_blank"><?php echo esc_html( atika_page_url( 'login' ) ); ?></a></li>
			<li>لوحة التحكم: <a href="<?php echo esc_url( atika_page_url( 'dashboard' ) ); ?>" target="_blank"><?php echo esc_html( atika_page_url( 'dashboard' ) ); ?></a></li>
		</ul>
		<h2>إرسال رسالة تجريبية</h2>
		<p>تأكدي أن رسائل التوثيق تصل قبل مشاركة رابط التسجيل.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'atika_test_mail' ); ?>
			<input type="hidden" name="action" value="atika_test_mail">
			<input type="email" name="to" class="regular-text" dir="ltr" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>">
			<?php submit_button( 'إرسال', 'secondary', 'submit', false ); ?>
		</form>
		<?php if ( isset( $_GET['mail'] ) ) : ?>
			<div class="notice notice-<?php echo 'ok' === $_GET['mail'] ? 'success' : 'error'; ?>"><p><?php echo 'ok' === $_GET['mail'] ? 'تم الإرسال. تفقّدي البريد (والرسائل غير المرغوبة).' : 'فشل الإرسال. فعّلي SMTP كما في دليل التثبيت.'; ?></p></div>
		<?php endif; ?>
	</div>
	<?php
}

add_action( 'admin_post_atika_test_mail', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'غير مصرح.', 403 );
	}
	check_admin_referer( 'atika_test_mail' );
	$to = sanitize_email( wp_unslash( isset( $_POST['to'] ) ? $_POST['to'] : '' ) );
	$ok = $to && atika_mail( $to, 'رسالة تجريبية | ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'البريد يعمل', '<p>إذا وصلتك هذه الرسالة فرسائل توثيق رئيسات الأقسام ستصل أيضاً.</p>' );
	wp_safe_redirect( admin_url( 'admin.php?page=atika-settings&mail=' . ( $ok ? 'ok' : 'fail' ) ) );
	exit;
} );

/* Show head info on the user profile screen. */
add_action( 'edit_user_profile', function ( $user ) {
	if ( ! atika_is_head( $user ) ) {
		return;
	}
	$l = atika_status_labels();
	echo '<h2>بيانات رئيسة القسم</h2><table class="form-table"><tr><th>المادة</th><td>' . esc_html( atika_head_subject_name( $user->ID ) ) . '</td></tr><tr><th>الحالة</th><td>' . esc_html( $l[ atika_head_status( $user->ID ) ] ) . '</td></tr><tr><th>الجوال</th><td dir="ltr" style="text-align:right">' . esc_html( get_user_meta( $user->ID, 'atika_phone', true ) ) . '</td></tr></table>';
} );

/* Dashboard widget for the admin. */
add_action( 'wp_dashboard_setup', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	wp_add_dashboard_widget( 'atika_overview', 'منصة الإنجازات', function () {
		$n  = atika_pending_count();
		$c  = wp_count_posts( ATIKA_CPT );
		$hs = count( get_users( array( 'role' => ATIKA_ROLE, 'meta_key' => 'atika_status', 'meta_value' => ATIKA_STATUS_ACTIVE, 'fields' => 'ID' ) ) );
		echo '<p><strong>' . (int) $c->publish . '</strong> إنجاز منشور · <strong>' . (int) $hs . '</strong> رئيسة قسم مفعّلة</p>';
		if ( $n ) {
			echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=atika-heads&status=pending' ) ) . '">' . (int) $n . ' طلب بانتظار الاعتماد</a></p>';
		}
	} );
} );
