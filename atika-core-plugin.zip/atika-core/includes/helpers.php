<?php
defined( 'ABSPATH' ) || exit;

/* ---------- Settings ---------- */

function atika_default_settings() {
	return array(
		'require_approval' => 1,
		'notify_email'     => get_option( 'admin_email' ),
		'max_images'       => 10,
		'max_image_mb'     => 5,
		'token_hours'      => 48,
		'cleanup_days'     => 7,
	);
}

function atika_setting( $key ) {
	$s = wp_parse_args( (array) get_option( 'atika_settings', array() ), atika_default_settings() );
	return isset( $s[ $key ] ) ? $s[ $key ] : null;
}

/* ---------- Pages ---------- */

function atika_page_id( $key ) {
	$ids = get_option( 'atika_pages', array() );
	return isset( $ids[ $key ] ) ? (int) $ids[ $key ] : 0;
}

function atika_page_url( $key, $args = array() ) {
	$id  = atika_page_id( $key );
	$url = $id ? get_permalink( $id ) : home_url( '/' );
	return $args ? add_query_arg( $args, $url ) : $url;
}

function atika_is_system_page() {
	if ( ! is_page() ) {
		return false;
	}
	$id = get_queried_object_id();
	return in_array( $id, array_filter( array_map( 'intval', (array) get_option( 'atika_pages', array() ) ) ), true );
}

/* ---------- Head status ---------- */

const ATIKA_STATUS_UNVERIFIED = 'unverified';
const ATIKA_STATUS_PENDING    = 'pending';
const ATIKA_STATUS_ACTIVE     = 'active';
const ATIKA_STATUS_SUSPENDED  = 'suspended';

function atika_status_labels() {
	return array(
		ATIKA_STATUS_UNVERIFIED => 'لم يُوثَّق البريد',
		ATIKA_STATUS_PENDING    => 'بانتظار الاعتماد',
		ATIKA_STATUS_ACTIVE     => 'مفعّلة',
		ATIKA_STATUS_SUSPENDED  => 'موقوفة',
	);
}

function atika_is_head( $user = null ) {
	$user = $user ? $user : wp_get_current_user();
	return $user && $user->exists() && in_array( ATIKA_ROLE, (array) $user->roles, true );
}

function atika_head_status( $user_id ) {
	$s = get_user_meta( $user_id, 'atika_status', true );
	return $s ? $s : ATIKA_STATUS_UNVERIFIED;
}

/** Term ID of the subject a head owns (0 if none yet). */
function atika_head_subject_id( $user_id ) {
	$tid = (int) get_user_meta( $user_id, 'atika_subject_term', true );
	return ( $tid && term_exists( $tid, ATIKA_TAX_SUBJECT ) ) ? $tid : 0;
}

function atika_head_subject_name( $user_id ) {
	$tid = atika_head_subject_id( $user_id );
	if ( $tid ) {
		$t = get_term( $tid, ATIKA_TAX_SUBJECT );
		return $t && ! is_wp_error( $t ) ? $t->name : '';
	}
	return (string) get_user_meta( $user_id, 'atika_subject_name', true );
}

/** Head who owns a subject term (0 if none). */
function atika_subject_head( $term_id ) {
	return (int) get_term_meta( $term_id, 'atika_head', true );
}

/* ---------- Subject names ---------- */

/** Clean up what a head typed as her subject name. */
function atika_clean_subject( $name ) {
	$name = sanitize_text_field( wp_unslash( $name ) );
	$name = preg_replace( '/\s+/u', ' ', $name );
	return trim( $name );
}

/**
 * A comparison key so that "الرياضيات", "رياضيات", "مادة الرياضيّات"
 * all count as the same subject.
 */
function atika_subject_key( $name ) {
	$s = atika_clean_subject( $name );
	$s = preg_replace( '/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $s ); // diacritics + tatweel
	$s = strtr( $s, array( 'أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ٱ' => 'ا', 'ة' => 'ه', 'ى' => 'ي', 'ؤ' => 'و', 'ئ' => 'ي' ) );
	$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( $s ) : strtolower( $s );
	$s = preg_replace( '/^(قسم|ماده)\s+/u', '', $s );
	$words = explode( ' ', $s );
	foreach ( $words as &$w ) {
		if ( mb_strlen( $w ) > 3 && 0 === mb_strpos( $w, 'ال' ) ) {
			$w = mb_substr( $w, 2 );
		}
	}
	unset( $w );
	$s = implode( ' ', $words );
	return preg_replace( '/[^\p{L}\p{N} ]/u', '', $s );
}

/**
 * Who already holds this subject? Returns a user ID, or 0 when free.
 * Checks owned subject terms and requests from heads still waiting.
 */
function atika_subject_taken_by( $name, $exclude_user = 0 ) {
	$key = atika_subject_key( $name );
	if ( '' === $key ) {
		return 0;
	}
	$terms = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => false ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			$owner = atika_subject_head( $t->term_id );
			if ( $owner && $owner !== (int) $exclude_user && atika_subject_key( $t->name ) === $key && get_userdata( $owner ) ) {
				return $owner;
			}
		}
	}
	$waiting = get_users( array(
		'role'       => ATIKA_ROLE,
		'meta_key'   => 'atika_status',
		'meta_value' => array( ATIKA_STATUS_UNVERIFIED, ATIKA_STATUS_PENDING ),
		'meta_compare' => 'IN',
		'exclude'    => $exclude_user ? array( $exclude_user ) : array(),
		'fields'     => array( 'ID' ),
	) );
	foreach ( $waiting as $u ) {
		if ( atika_subject_key( get_user_meta( $u->ID, 'atika_subject_name', true ) ) === $key ) {
			return (int) $u->ID;
		}
	}
	return 0;
}

/**
 * Give a head her subject term. Reuses an ownerless term with the same
 * name (e.g. left behind by a deleted head), otherwise creates one.
 */
function atika_assign_subject( $user_id ) {
	$existing = atika_head_subject_id( $user_id );
	if ( $existing ) {
		return $existing;
	}
	$name = (string) get_user_meta( $user_id, 'atika_subject_name', true );
	if ( '' === $name ) {
		return 0;
	}
	$key   = atika_subject_key( $name );
	$terms = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => false ) );
	$tid   = 0;
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			$owner = atika_subject_head( $t->term_id );
			if ( atika_subject_key( $t->name ) === $key && ( ! $owner || ! get_userdata( $owner ) ) ) {
				$tid = $t->term_id;
				break;
			}
		}
	}
	if ( ! $tid ) {
		$r = wp_insert_term( $name, ATIKA_TAX_SUBJECT, array( 'slug' => atika_unique_term_slug( $name ) ) );
		if ( is_wp_error( $r ) ) {
			return 0;
		}
		$tid = (int) $r['term_id'];
	}
	update_term_meta( $tid, 'atika_head', $user_id );
	update_user_meta( $user_id, 'atika_subject_term', $tid );
	return $tid;
}

function atika_unique_term_slug( $name ) {
	$base = sanitize_title( $name );
	if ( '' === $base ) {
		$base = 'subject';
	}
	$slug = $base;
	$i    = 2;
	while ( term_exists( $slug, ATIKA_TAX_SUBJECT ) ) {
		$slug = $base . '-' . $i++;
	}
	return $slug;
}

/* ---------- Flash notices (per user/session cookie) ---------- */

function atika_flash_key() {
	if ( is_user_logged_in() ) {
		return 'atika_flash_u' . get_current_user_id();
	}
	return '';
}

function atika_flash( $msg, $type = 'success' ) {
	$k = atika_flash_key();
	if ( $k ) {
		set_transient( $k, array( 'msg' => $msg, 'type' => $type ), 120 );
	}
}

function atika_take_flash() {
	$k = atika_flash_key();
	if ( ! $k ) {
		return null;
	}
	$f = get_transient( $k );
	if ( $f ) {
		delete_transient( $k );
	}
	return $f ? $f : null;
}

function atika_notice( $msg, $type = 'error' ) {
	return '<div class="atk-notice atk-notice-' . esc_attr( $type ) . '" role="' . ( 'error' === $type ? 'alert' : 'status' ) . '">' . wp_kses_post( $msg ) . '</div>';
}

/* ---------- Rate limit by IP ---------- */

function atika_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	return preg_replace( '/[^0-9a-f:.]/i', '', $ip );
}

/** True when the action is still allowed; counts the attempt. */
function atika_rate_ok( $action, $limit, $window ) {
	$k = 'atika_rl_' . $action . '_' . md5( atika_client_ip() );
	$n = (int) get_transient( $k );
	if ( $n >= $limit ) {
		return false;
	}
	set_transient( $k, $n + 1, $window );
	return true;
}

/* ---------- Misc ---------- */

function atika_logo_url() {
	$id = (int) get_theme_mod( 'custom_logo' );
	if ( $id ) {
		$src = wp_get_attachment_image_url( $id, 'medium_large' );
		if ( $src ) {
			return $src;
		}
	}
	return ATIKA_URL . 'assets/img/logo.png';
}

function atika_ar_num( $n ) {
	return strtr( (string) $n, array( '0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩' ) );
}

/** Keep the system pages out of page caches (LiteSpeed on Hostinger, etc.). */
add_action( 'template_redirect', function () {
	if ( atika_is_system_page() ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		do_action( 'litespeed_control_set_nocache', 'atika system page' );
	}
}, 1 );
