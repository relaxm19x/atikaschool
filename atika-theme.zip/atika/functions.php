<?php
defined( 'ABSPATH' ) || exit;

define( 'ATIKA_THEME_VERSION', '1.1.0' );

require get_template_directory() . '/inc/icons.php';
require get_template_directory() . '/inc/customizer.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 270, 'width' => 720, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'responsive-embeds' );
	register_nav_menus( array( 'primary' => 'القائمة الرئيسية' ) );
	add_image_size( 'atika-card', 720, 540, true );
	add_image_size( 'atika-wide', 1600, 1200, false );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'atika-fonts', 'https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'atika-main', get_template_directory_uri() . '/assets/css/main.css', array(), ATIKA_THEME_VERSION );
	wp_add_inline_style( 'atika-main', atika_theme_color_css() );
	wp_enqueue_script( 'atika-main', get_template_directory_uri() . '/assets/js/main.js', array(), ATIKA_THEME_VERSION, true );
} );

add_action( 'wp_head', function () {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}, 1 );

/** Colors the admin picks in the Customizer become CSS tokens. */
function atika_theme_color_css() {
	$navy   = sanitize_hex_color( get_theme_mod( 'atika_color_navy', '#1b2242' ) );
	$green  = sanitize_hex_color( get_theme_mod( 'atika_color_green', '#037b3e' ) );
	$maroon = sanitize_hex_color( get_theme_mod( 'atika_color_maroon', '#7a2934' ) );
	return ':root{--navy:' . $navy . ';--green:' . $green . ';--maroon:' . $maroon . ';}';
}

function atika_has_core() {
	return defined( 'ATIKA_CPT' );
}

function atika_theme_logo_url() {
	$id = (int) get_theme_mod( 'custom_logo' );
	$src = $id ? wp_get_attachment_image_url( $id, 'full' ) : '';
	return $src ? $src : get_template_directory_uri() . '/assets/img/logo.png';
}

function atika_num( $n ) {
	return strtr( (string) $n, array( '0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩' ) );
}

/** "منصة *إنجازات* المعلمات" → emphasis on the starred word. */
function atika_em( $text ) {
	return preg_replace( '/\*(.+?)\*/u', '<em>$1</em>', esc_html( $text ) );
}

/* Site stats, cached for an hour and refreshed when an achievement changes. */
function atika_site_stats() {
	$s = get_transient( 'atika_stats' );
	if ( is_array( $s ) ) {
		return $s;
	}
	$s = array( 'total' => 0, 'teachers' => 0, 'photos' => 0, 'subjects' => 0 );
	if ( atika_has_core() ) {
		$ids = get_posts( array( 'post_type' => ATIKA_CPT, 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids' ) );
		$t   = array();
		foreach ( $ids as $id ) {
			$s['photos'] += count( atika_gallery_ids( $id ) );
			$n = get_post_meta( $id, 'atika_teacher', true );
			if ( $n ) {
				$t[ $n ] = 1;
			}
		}
		$s['total']    = count( $ids );
		$s['teachers'] = count( $t );
		$subs          = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => false, 'fields' => 'ids' ) );
		$s['subjects'] = is_wp_error( $subs ) ? 0 : count( $subs );
	}
	set_transient( 'atika_stats', $s, HOUR_IN_SECONDS );
	return $s;
}
add_action( 'save_post', function ( $id, $p ) {
	if ( atika_has_core() && ATIKA_CPT === $p->post_type ) {
		delete_transient( 'atika_stats' );
	}
}, 10, 2 );
add_action( 'deleted_post', function () {
	delete_transient( 'atika_stats' );
} );
add_action( 'created_term', function () {
	delete_transient( 'atika_stats' );
} );

/* Section / subject archives share the achievements archive template. */
add_filter( 'template_include', function ( $t ) {
	if ( atika_has_core() && ( is_tax( ATIKA_TAX_SECTION ) || is_tax( ATIKA_TAX_SUBJECT ) ) ) {
		$a = locate_template( 'archive-atika_achievement.php' );
		return $a ? $a : $t;
	}
	return $t;
} );

/* Achievement meta + small helpers for templates. */
function atika_card_data( $post_id ) {
	$sec  = get_the_terms( $post_id, ATIKA_TAX_SECTION );
	$sub  = get_the_terms( $post_id, ATIKA_TAX_SUBJECT );
	$sec  = $sec && ! is_wp_error( $sec ) ? $sec[0] : null;
	$sub  = $sub && ! is_wp_error( $sub ) ? $sub[0] : null;
	return array(
		'section' => $sec,
		'subject' => $sub,
		'color'   => $sec ? atika_section_color( $sec ) : '#1b2242',
		'teacher' => get_post_meta( $post_id, 'atika_teacher', true ),
		'images'  => atika_gallery_ids( $post_id ),
	);
}

function atika_pagination( $q = null ) {
	$links = paginate_links( array(
		'total'     => $q ? $q->max_num_pages : $GLOBALS['wp_query']->max_num_pages,
		'current'   => max( 1, get_query_var( 'paged' ) ),
		'prev_text' => 'السابق',
		'next_text' => 'التالي',
		'type'      => 'array',
		'mid_size'  => 1,
	) );
	if ( $links ) {
		echo '<nav class="pager" aria-label="الصفحات">' . implode( '', array_map( function ( $l ) {
			return strtr( $l, array( '0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩' ) );
		}, $links ) ) . '</nav>';
	}
}

/* Header account area. */
function atika_account_link() {
	if ( ! atika_has_core() ) {
		return '';
	}
	if ( is_user_logged_in() ) {
		$u = wp_get_current_user();
		if ( ! atika_can_publish( $u ) ) {
			return '<a class="btn btn-ghost" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">خروج</a>';
		}
		$name = preg_replace( '/^(أ\.|د\.)\s*/u', '', $u->display_name );
		return '<a class="btn btn-ghost acct" href="' . esc_url( atika_page_url( 'dashboard' ) ) . '"><span class="mini-av">' . esc_html( mb_substr( $name, 0, 1 ) ) . '</span>لوحة التحكم</a>';
	}
	$out = '';
	if ( atika_registration_open() ) {
		$out .= '<a class="btn btn-ghost" href="' . esc_url( atika_page_url( 'register' ) ) . '">تسجيل رئيسة قسم</a>';
	}
	return $out . '<a class="btn btn-navy" href="' . esc_url( atika_page_url( 'login' ) ) . '">' . atika_svg( 'login' ) . '<span>دخول فريق العمل</span></a>';
}

function atika_default_menu() {
	$items = array( home_url( '/' ) => 'الرئيسية' );
	if ( atika_has_core() ) {
		$items[ get_post_type_archive_link( ATIKA_CPT ) ] = 'الإنجازات';
		$items[ home_url( '/#subjects' ) ]                = 'المواد';
	}
	$items[ home_url( '/#staff' ) ] = 'الإدارة';
	echo '<ul class="menu">';
	foreach ( $items as $u => $l ) {
		echo '<li><a href="' . esc_url( $u ) . '">' . esc_html( $l ) . '</a></li>';
	}
	echo '</ul>';
}

/* Remove the "Archives:" prefix. */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );

/* Body class for system pages so the theme can widen them. */
add_filter( 'body_class', function ( $c ) {
	if ( function_exists( 'atika_is_system_page' ) && atika_is_system_page() ) {
		$c[] = 'atika-system';
	}
	return $c;
} );

/* Admin notice when the plugin is missing. */
add_action( 'admin_notices', function () {
	if ( ! atika_has_core() && current_user_can( 'activate_plugins' ) ) {
		echo '<div class="notice notice-warning"><p>قالب عاتكة يحتاج إضافة <strong>منصة إنجازات عاتكة</strong>. ارفعيها وفعّليها من صفحة الإضافات.</p></div>';
	}
} );

/* Favicon from the school crest when the admin has not set a Site Icon. */
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$u = get_template_directory_uri() . '/assets/img/';
	echo '<link rel="icon" href="' . esc_url( $u . 'icon.png' ) . '" sizes="512x512">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
}, 2 );

/* Description + share preview (WhatsApp, X, etc.). Skipped if an SEO plugin is active. */
add_action( 'wp_head', function () {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || class_exists( 'All_in_One_SEO_Pack' ) || defined( 'AIOSEO_VERSION' ) ) {
		return;
	}
	$title = wp_get_document_title();
	$desc  = atika_mod( 'hero_text' );
	$img   = get_template_directory_uri() . '/assets/img/og.jpg';
	$url   = home_url( add_query_arg( array() ) );
	$type  = 'website';
	if ( atika_has_core() && is_singular( ATIKA_CPT ) ) {
		$id   = get_queried_object_id();
		$desc = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $id ) ), 30, '…' );
		$ids  = atika_gallery_ids( $id );
		if ( $ids ) {
			$img = wp_get_attachment_image_url( $ids[0], 'atika-wide' );
		}
		$url  = get_permalink( $id );
		$type = 'article';
	} elseif ( is_tax() || is_category() ) {
		$t = get_queried_object();
		if ( $t && ! empty( $t->description ) ) {
			$desc = $t->description;
		}
		$url = get_term_link( $t );
	} elseif ( is_singular() ) {
		$url = get_permalink();
	}
	$desc = wp_strip_all_tags( $desc );
	printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:locale" content="ar_KW">' . "\n" );
	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $type ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $desc ) );
	printf( '<meta property="og:url" content="%s">' . "\n", esc_url( is_wp_error( $url ) ? home_url( '/' ) : $url ) );
	printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $img ) );
	printf( '<meta name="twitter:card" content="summary_large_image">' . "\n" );
}, 3 );

/* System pages (login, dashboard) should not show up in Google. */
add_filter( 'wp_robots', function ( $r ) {
	if ( function_exists( 'atika_is_system_page' ) && atika_is_system_page() ) {
		$r['noindex'] = true;
		$r['nofollow'] = true;
	}
	return $r;
} );
