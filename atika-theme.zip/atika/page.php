<?php
defined( 'ABSPATH' ) || exit;
get_header();
$system = function_exists( 'atika_is_system_page' ) && atika_is_system_page();
while ( have_posts() ) :
	the_post();
	?>
	<div class="wrap <?php echo $system ? 'system-page' : 'block prose-page'; ?>">
		<?php if ( ! $system ) : ?><h1 class="page-title"><?php the_title(); ?></h1><?php endif; ?>
		<div class="<?php echo $system ? '' : 'prose'; ?>"><?php the_content(); ?></div>
	</div>
	<?php
endwhile;
get_footer();
