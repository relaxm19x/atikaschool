<?php
defined( 'ABSPATH' ) || exit;
get_header();

$is_sec = is_tax( ATIKA_TAX_SECTION );
$is_sub = is_tax( ATIKA_TAX_SUBJECT );
$term   = ( $is_sec || $is_sub ) ? get_queried_object() : null;
$q      = sanitize_text_field( (string) get_query_var( 'q' ) );
$cur_sec = $is_sec ? $term->slug : sanitize_title( (string) get_query_var( 'section' ) );
$cur_sub = $is_sub ? $term->slug : sanitize_title( (string) get_query_var( 'subject' ) );
$base    = $term ? get_term_link( $term ) : get_post_type_archive_link( ATIKA_CPT );
$color   = $is_sec ? atika_section_color( $term ) : '';
$head    = $is_sub ? atika_subject_head( $term->term_id ) : 0;
$head_u  = $head ? get_userdata( $head ) : null;
?>
<section class="page-hero"<?php echo $color ? ' style="--c:' . esc_attr( $color ) . '"' : ''; ?>>
	<div class="wrap">
		<nav class="crumbs" aria-label="مسار التنقل"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">الرئيسية</a><span>/</span><a href="<?php echo esc_url( get_post_type_archive_link( ATIKA_CPT ) ); ?>">الإنجازات</a><?php if ( $term ) : ?><span>/</span><span><?php echo esc_html( $term->name ); ?></span><?php endif; ?></nav>
		<div class="ph-row">
			<?php if ( $is_sec ) : ?><span class="ic-wrap big"><?php echo atika_section_icon( $term ); // phpcs:ignore ?></span><?php elseif ( $is_sub ) : ?><span class="ic-wrap big"><?php echo atika_svg( 'book' ); // phpcs:ignore ?></span><?php endif; ?>
			<div>
				<div class="eyebrow"><?php echo $is_sec ? 'محور' : ( $is_sub ? 'قسم مادة' : 'أرشيف' ); ?></div>
				<h1><?php echo $term ? esc_html( $term->name ) : 'كل الإنجازات'; ?></h1>
				<p>
					<?php
					if ( $is_sub && $head_u ) {
						echo 'رئيسة القسم: ' . esc_html( $head_u->display_name ) . ' · ';
					} elseif ( $is_sec && $term->description ) {
						echo esc_html( $term->description ) . ' · ';
					}
					echo esc_html( atika_num( (int) $GLOBALS['wp_query']->found_posts ) ) . ' إنجاز';
					?>
				</p>
			</div>
		</div>
	</div>
</section>

<div class="wrap block">
	<form class="toolbar" method="get" action="<?php echo esc_url( $base ); ?>" role="search">
		<label class="search"><?php echo atika_svg( 'search' ); // phpcs:ignore ?><input type="search" name="q" id="arch-q" value="<?php echo esc_attr( $q ); ?>" placeholder="ابحثي بعنوان الإنجاز أو اسم المعلمة" aria-label="بحث"></label>
		<?php if ( ! $is_sec ) : ?>
			<select name="section" id="arch-sec" aria-label="المحور" onchange="this.form.submit()">
				<option value="">كل المحاور</option>
				<?php foreach ( atika_get_sections() as $s ) : ?><option value="<?php echo esc_attr( $s->slug ); ?>" <?php selected( $cur_sec, $s->slug ); ?>><?php echo esc_html( $s->name ); ?></option><?php endforeach; ?>
			</select>
		<?php endif; ?>
		<?php if ( ! $is_sub ) :
			$subs = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => true ) );
			if ( $subs && ! is_wp_error( $subs ) ) : ?>
				<select name="subject" id="arch-sub" aria-label="المادة" onchange="this.form.submit()">
					<option value="">كل المواد</option>
					<?php foreach ( $subs as $s ) : ?><option value="<?php echo esc_attr( $s->slug ); ?>" <?php selected( rawurldecode( $cur_sub ), rawurldecode( $s->slug ) ); ?>><?php echo esc_html( $s->name ); ?></option><?php endforeach; ?>
				</select>
			<?php endif;
		endif; ?>
		<button class="btn btn-navy" type="submit">بحث</button>
		<?php if ( $q || ( ! $is_sec && $cur_sec ) || ( ! $is_sub && $cur_sub ) ) : ?><a class="btn btn-ghost" href="<?php echo esc_url( $base ); ?>">مسح</a><?php endif; ?>
	</form>

	<?php if ( have_posts() ) : ?>
		<div class="wall">
			<?php
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/card' );
			}
			?>
		</div>
		<?php atika_pagination(); ?>
	<?php else : ?>
		<div class="empty">
			<?php echo atika_svg( 'image' ); // phpcs:ignore ?>
			<h3><?php echo $q ? 'لا توجد نتائج مطابقة' : 'لا توجد إنجازات هنا بعد'; ?></h3>
			<p><?php echo $q ? 'جرّبي كلمة أخرى أو امسحي التصفية.' : 'ستظهر الإنجازات هنا فور نشرها.'; ?></p>
		</div>
	<?php endif; ?>
</div>
<?php
get_footer();
