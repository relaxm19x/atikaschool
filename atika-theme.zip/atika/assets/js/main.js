(function () {
  'use strict';

  // Mobile menu
  var header = document.querySelector('.site-header');
  var toggle = document.querySelector('.nav-toggle');
  if (header && toggle) {
    toggle.addEventListener('click', function () {
      var open = header.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  function toast(msg) {
    var t = document.createElement('div');
    t.className = 'toast';
    t.setAttribute('role', 'status');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2400);
  }

  // Copy link
  document.addEventListener('click', function (e) {
    var b = e.target.closest('.copy-link');
    if (!b) return;
    var url = b.dataset.url;
    var done = function () { toast('تم نسخ الرابط'); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(done, function () { window.prompt('انسخي الرابط:', url); });
    } else {
      window.prompt('انسخي الرابط:', url);
    }
  });

  // Gallery + lightbox
  var g = document.querySelector('[data-gallery]');
  if (!g) return;
  var main = g.querySelector('[data-main]');
  var strip = g.querySelectorAll('.g-strip button');
  var tpl = g.querySelector('template[data-all]');
  var all = tpl ? Array.prototype.map.call(tpl.content.querySelectorAll('i'), function (i) { return i.dataset.src; }) : [];
  var cur = 0;

  strip.forEach(function (btn) {
    btn.addEventListener('click', function () {
      cur = +btn.dataset.idx;
      main.removeAttribute('srcset');
      main.src = btn.dataset.full;
      strip.forEach(function (x) { x.classList.toggle('on', x === btn); });
    });
  });

  var lb = document.querySelector('.lightbox');
  if (!lb || !all.length) return;
  var lbImg = lb.querySelector('img');
  var lbCount = lb.querySelector('.lb-count');
  var nav = lb.querySelectorAll('.lb-nav');
  function show(i) {
    cur = (i + all.length) % all.length;
    lbImg.src = all[cur];
    lbCount.textContent = all.length > 1 ? (cur + 1) + ' / ' + all.length : '';
  }
  function open() {
    nav.forEach(function (n) { n.hidden = all.length < 2; });
    show(cur); lb.hidden = false; document.body.style.overflow = 'hidden'; lb.querySelector('.lb-close').focus();
  }
  function close() { lb.hidden = true; document.body.style.overflow = ''; }
  g.querySelector('.g-main').addEventListener('click', open);
  lb.querySelector('.lb-close').addEventListener('click', close);
  lb.querySelector('.lb-prev').addEventListener('click', function () { show(cur - 1); });
  lb.querySelector('.lb-next').addEventListener('click', function () { show(cur + 1); });
  lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
  document.addEventListener('keydown', function (e) {
    if (lb.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') show(cur + 1);
    if (e.key === 'ArrowRight') show(cur - 1);
  });
})();
