<?php
defined( 'ABSPATH' ) || exit;
get_header();
$core  = atika_has_core();
$stats = atika_site_stats();
?>
<section class="hero wrap">
	<div class="hero-text">
		<div class="eyebrow"><?php echo esc_html( atika_mod( 'hero_eyebrow' ) ); ?></div>
		<h1><?php echo atika_em( atika_mod( 'hero_title' ) ); // phpcs:ignore -- escaped in atika_em ?></h1>
		<p><?php echo esc_html( atika_mod( 'hero_text' ) ); ?></p>
		<div class="actions">
			<?php if ( $core ) : ?>
				<a class="btn btn-navy" href="<?php echo esc_url( get_post_type_archive_link( ATIKA_CPT ) ); ?>"><?php echo esc_html( atika_mod( 'hero_btn' ) ); ?></a>
				<?php if ( ! is_user_logged_in() ) : ?>
					<a class="btn btn-ghost" href="<?php echo esc_url( atika_page_url( 'login' ) ); ?>">دخول رئيسات الأقسام</a>
				<?php else : ?>
					<a class="btn btn-ghost" href="<?php echo esc_url( atika_page_url( 'dashboard' ) ); ?>">لوحة التحكم</a>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
	<div class="hero-logo">
		<img src="<?php echo esc_url( atika_theme_logo_url() ); ?>" alt="" width="420" height="157">
		<?php if ( atika_mod( 'show_stats' ) ) : ?>
			<div class="stats">
				<div><b><?php echo esc_html( atika_num( $stats['total'] ) ); ?></b><span>إنجاز موثّق</span></div>
				<div><b><?php echo esc_html( atika_num( $stats['teachers'] ) ); ?></b><span>معلمة مشاركة</span></div>
				<div><b><?php echo esc_html( atika_num( $stats['photos'] ) ); ?></b><span>صورة</span></div>
			</div>
		<?php endif; ?>
	</div>
</section>

<?php if ( atika_mod( 'staff_show' ) ) : ?>
	<section id="staff" class="wrap staff" aria-label="إدارة المدرسة">
		<?php
		$tones = array( 1 => '', 2 => 'var(--green)', 3 => 'var(--maroon)', 4 => 'var(--slate)' );
		for ( $i = 1; $i <= 4; $i++ ) :
			$n = trim( atika_mod( "staff_{$i}_name" ) );
			if ( '' === $n ) {
				continue;
			}
			$initial = mb_substr( preg_replace( '/^(أ\.|د\.|م\.)\s*/u', '', $n ), 0, 1 );
			?>
			<div class="person<?php echo 1 === $i ? ' lead' : ''; ?>">
				<div class="avatar"<?php echo $tones[ $i ] ? ' style="background:' . esc_attr( $tones[ $i ] ) . '"' : ''; ?>><?php echo esc_html( $initial ); ?></div>
				<div><div class="role"><?php echo esc_html( atika_mod( "staff_{$i}_role" ) ); ?></div><div class="name"><?php echo esc_html( $n ); ?></div></div>
			</div>
		<?php endfor; ?>
	</section>
<?php endif; ?>

<?php if ( $core ) : ?>
	<section id="sections" class="wrap block">
		<div class="sec-head"><div><h2><?php echo esc_html( atika_mod( 'sections_title' ) ); ?></h2><p><?php echo esc_html( atika_mod( 'sections_sub' ) ); ?></p></div></div>
		<div class="tiles">
			<?php foreach ( atika_get_sections() as $s ) : ?>
				<a class="tile" href="<?php echo esc_url( get_term_link( $s ) ); ?>" style="--c:<?php echo esc_attr( atika_section_color( $s ) ); ?>">
					<span class="ic-wrap"><?php echo atika_section_icon( $s ); // phpcs:ignore ?></span>
					<h3><?php echo esc_html( $s->name ); ?></h3>
					<?php if ( $s->description ) : ?><p><?php echo esc_html( $s->description ); ?></p><?php endif; ?>
					<span class="count"><?php echo esc_html( atika_num( (int) $s->count ) ); ?> <?php echo 1 === (int) $s->count ? 'إنجاز' : 'إنجازات'; ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>

	<?php
	$subjects = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => false, 'orderby' => 'name' ) );
	$subjects = is_wp_error( $subjects ) ? array() : array_filter( $subjects, function ( $t ) {
		$h = atika_subject_head( $t->term_id );
		return $t->count > 0 || ( $h && ATIKA_STATUS_ACTIVE === atika_head_status( $h ) );
	} );
	if ( atika_mod( 'subjects_show' ) && $subjects ) :
		?>
		<section id="subjects" class="wrap block">
			<div class="sec-head"><div><h2><?php echo esc_html( atika_mod( 'subjects_title' ) ); ?></h2><p><?php echo esc_html( atika_mod( 'subjects_sub' ) ); ?></p></div></div>
			<div class="subjects">
				<?php foreach ( $subjects as $t ) :
					$h = atika_subject_head( $t->term_id );
					$hu = $h ? get_userdata( $h ) : null;
					?>
					<a class="subject" href="<?php echo esc_url( get_term_link( $t ) ); ?>">
						<span class="sub-ic"><?php echo atika_svg( 'book' ); // phpcs:ignore ?></span>
						<span class="sub-main"><strong><?php echo esc_html( $t->name ); ?></strong>
						<?php if ( $hu ) : ?><small>رئيسة القسم: <?php echo esc_html( $hu->display_name ); ?></small><?php endif; ?></span>
						<span class="sub-n"><?php echo esc_html( atika_num( (int) $t->count ) ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<section id="achievements" class="wrap block">
		<div class="sec-head">
			<div><h2><?php echo esc_html( atika_mod( 'latest_title' ) ); ?></h2><p>آخر ما نشرته رئيسات الأقسام</p></div>
			<a class="btn btn-ghost" href="<?php echo esc_url( get_post_type_archive_link( ATIKA_CPT ) ); ?>">عرض كل الإنجازات <?php echo atika_svg( 'arrow' ); // phpcs:ignore ?></a>
		</div>
		<?php
		$latest = new WP_Query( array( 'post_type' => ATIKA_CPT, 'posts_per_page' => max( 3, (int) atika_mod( 'latest_count' ) ), 'no_found_rows' => true ) );
		if ( $latest->have_posts() ) :
			echo '<div class="wall">';
			while ( $latest->have_posts() ) {
				$latest->the_post();
				get_template_part( 'template-parts/card' );
			}
			echo '</div>';
			wp_reset_postdata();
		else :
			?>
			<div class="empty">
				<?php echo atika_svg( 'image' ); // phpcs:ignore ?>
				<h3>لا توجد إنجازات منشورة بعد</h3>
				<p>عندما تنشر رئيسات الأقسام إنجازات معلماتهن ستظهر هنا.</p>
			</div>
		<?php endif; ?>
	</section>
<?php endif; ?>

<?php
get_footer();
