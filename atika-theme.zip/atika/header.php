<!doctype html>
<html <?php language_attributes(); ?><?php echo is_rtl() ? '' : ' dir="rtl"'; ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#ffffff">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#main">تخطَّ إلى المحتوى</a>
<div class="stripe" aria-hidden="true"><i></i><i></i><i></i></div>
<header class="site-header">
	<div class="wrap bar">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<img src="<?php echo esc_url( atika_theme_logo_url() ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="180" height="67">
		</a>
		<nav class="main-nav" id="main-nav" aria-label="القائمة الرئيسية">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'menu',
				'depth'          => 1,
				'fallback_cb'    => 'atika_default_menu',
			) );
			?>
			<div class="nav-acct"><?php echo atika_account_link(); // phpcs:ignore ?></div>
		</nav>
		<button class="nav-toggle" type="button" aria-controls="main-nav" aria-expanded="false" aria-label="القائمة">
			<?php echo atika_svg( 'menu', 'ic i-open' ) . atika_svg( 'close', 'ic i-close' ); // phpcs:ignore ?>
		</button>
	</div>
</header>
<main id="main" class="site-main">
