<?php
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	$d      = atika_card_data( get_the_ID() );
	$head   = get_userdata( (int) get_post_field( 'post_author' ) );
	$is_head = $head && function_exists( 'atika_is_head' ) && atika_is_head( $head );
	?>
	<article class="wrap single" style="--c:<?php echo esc_attr( $d['color'] ); ?>">
		<nav class="crumbs" aria-label="مسار التنقل">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">الرئيسية</a><span>/</span>
			<a href="<?php echo esc_url( get_post_type_archive_link( ATIKA_CPT ) ); ?>">الإنجازات</a>
			<?php if ( $d['subject'] ) : ?><span>/</span><a href="<?php echo esc_url( get_term_link( $d['subject'] ) ); ?>"><?php echo esc_html( $d['subject']->name ); ?></a><?php endif; ?>
		</nav>

		<div class="single-grid">
			<div class="gallery" data-gallery>
				<?php if ( $d['images'] ) : ?>
					<button class="g-main" type="button" data-open="0" aria-label="تكبير الصورة">
						<?php echo wp_get_attachment_image( $d['images'][0], 'atika-wide', false, array( 'data-main' => '1', 'fetchpriority' => 'high' ) ); // phpcs:ignore ?>
					</button>
					<?php if ( count( $d['images'] ) > 1 ) : ?>
						<div class="g-strip">
							<?php foreach ( $d['images'] as $i => $aid ) :
								$full = wp_get_attachment_image_url( $aid, 'atika-wide' );
								?>
								<button type="button" class="<?php echo 0 === $i ? 'on' : ''; ?>" data-idx="<?php echo (int) $i; ?>" data-full="<?php echo esc_url( $full ); ?>" aria-label="الصورة <?php echo esc_attr( atika_num( $i + 1 ) ); ?>">
									<?php echo wp_get_attachment_image( $aid, 'thumbnail', false, array( 'alt' => '', 'loading' => 'lazy' ) ); // phpcs:ignore ?>
								</button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<template data-all><?php foreach ( $d['images'] as $aid ) { echo '<i data-src="' . esc_url( wp_get_attachment_image_url( $aid, 'full' ) ) . '"></i>'; } ?></template>
				<?php else : ?>
					<div class="g-empty"><?php echo atika_svg( 'image' ); // phpcs:ignore ?></div>
				<?php endif; ?>
			</div>

			<div class="info">
				<div class="tags">
					<?php if ( $d['section'] ) : ?><a class="tag" href="<?php echo esc_url( get_term_link( $d['section'] ) ); ?>"><?php echo esc_html( $d['section']->name ); ?></a><?php endif; ?>
					<?php if ( $d['subject'] ) : ?><a class="tag tag-sub" href="<?php echo esc_url( get_term_link( $d['subject'] ) ); ?>"><?php echo esc_html( $d['subject']->name ); ?></a><?php endif; ?>
				</div>
				<h1><?php the_title(); ?></h1>
				<dl class="facts">
					<?php if ( $d['teacher'] ) : ?><div><dt><?php echo atika_svg( 'user' ); // phpcs:ignore ?>المعلمة</dt><dd><?php echo esc_html( $d['teacher'] ); ?></dd></div><?php endif; ?>
					<div><dt><?php echo atika_svg( 'calendar' ); // phpcs:ignore ?>التاريخ</dt><dd><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time></dd></div>
					<?php if ( $is_head ) : ?><div><dt><?php echo atika_svg( 'book' ); // phpcs:ignore ?>رئيسة القسم</dt><dd><?php echo esc_html( $head->display_name ); ?></dd></div><?php endif; ?>
				</dl>
				<div class="content"><?php echo wpautop( esc_html( get_the_content() ) ); // phpcs:ignore ?></div>
				<button class="btn btn-ghost copy-link" type="button" data-url="<?php echo esc_url( get_permalink() ); ?>"><?php echo atika_svg( 'link' ); // phpcs:ignore ?><span>نسخ رابط الإنجاز</span></button>
			</div>
		</div>
	</article>

	<?php
	if ( $d['subject'] ) :
		$rel = new WP_Query( array(
			'post_type'      => ATIKA_CPT,
			'posts_per_page' => 3,
			'post__not_in'   => array( get_the_ID() ),
			'no_found_rows'  => true,
			'tax_query'      => array( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'terms' => $d['subject']->term_id ) ), // phpcs:ignore
		) );
		if ( $rel->have_posts() ) :
			?>
			<section class="wrap block">
				<div class="sec-head"><div><h2>المزيد من <?php echo esc_html( $d['subject']->name ); ?></h2></div><a class="btn btn-ghost" href="<?php echo esc_url( get_term_link( $d['subject'] ) ); ?>">كل إنجازات القسم <?php echo atika_svg( 'arrow' ); // phpcs:ignore ?></a></div>
				<div class="wall">
					<?php
					while ( $rel->have_posts() ) {
						$rel->the_post();
						get_template_part( 'template-parts/card' );
					}
					wp_reset_postdata();
					?>
				</div>
			</section>
			<?php
		endif;
	endif;
endwhile;
?>
<div class="lightbox" hidden role="dialog" aria-modal="true" aria-label="عرض الصور">
	<button class="lb-close" type="button" aria-label="إغلاق"><?php echo atika_svg( 'close' ); // phpcs:ignore ?></button>
	<button class="lb-nav lb-prev" type="button" aria-label="السابقة"><?php echo atika_svg( 'arrow' ); // phpcs:ignore ?></button>
	<img alt="">
	<button class="lb-nav lb-next" type="button" aria-label="التالية"><?php echo atika_svg( 'arrow' ); // phpcs:ignore ?></button>
	<div class="lb-count"></div>
</div>
<?php
get_footer();
