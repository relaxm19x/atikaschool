<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="wrap block notfound">
	<div class="nf-num">٤٠٤</div>
	<h1>الصفحة غير موجودة</h1>
	<p>ربما تم حذف هذا الإنجاز أو تغيّر رابطه.</p>
	<div class="actions">
		<a class="btn btn-navy" href="<?php echo esc_url( home_url( '/' ) ); ?>">الصفحة الرئيسية</a>
		<?php if ( atika_has_core() ) : ?><a class="btn btn-ghost" href="<?php echo esc_url( get_post_type_archive_link( ATIKA_CPT ) ); ?>">كل الإنجازات</a><?php endif; ?>
	</div>
</div>
<?php
get_footer();
