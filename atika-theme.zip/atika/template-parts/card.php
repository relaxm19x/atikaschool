<?php
/** Achievement card. Expects to run inside the loop. */
defined( 'ABSPATH' ) || exit;
$d = atika_card_data( get_the_ID() );
?>
<article class="card" style="--c:<?php echo esc_attr( $d['color'] ); ?>">
	<a class="card-link" href="<?php the_permalink(); ?>">
		<div class="ph">
			<?php if ( $d['images'] ) : ?>
				<?php echo wp_get_attachment_image( $d['images'][0], 'atika-card', false, array( 'alt' => '', 'loading' => 'lazy' ) ); // phpcs:ignore ?>
			<?php else : ?>
				<span class="ph-empty"><?php echo atika_svg( 'image' ); // phpcs:ignore ?></span>
			<?php endif; ?>
			<?php if ( count( $d['images'] ) > 1 ) : ?><span class="more">+<?php echo esc_html( atika_num( count( $d['images'] ) - 1 ) ); ?> صور</span><?php endif; ?>
		</div>
		<div class="body">
			<div class="tags">
				<?php if ( $d['section'] ) : ?><span class="tag"><?php echo esc_html( $d['section']->name ); ?></span><?php endif; ?>
				<?php if ( $d['subject'] ) : ?><span class="tag tag-sub"><?php echo esc_html( $d['subject']->name ); ?></span><?php endif; ?>
			</div>
			<h3><?php the_title(); ?></h3>
			<p class="desc"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( get_the_content() ), 24, '…' ) ); ?></p>
			<div class="meta">
				<span class="mini-av"><?php echo esc_html( mb_substr( $d['teacher'] ? $d['teacher'] : 'م', 0, 1 ) ); ?></span>
				<span class="who"><?php echo esc_html( $d['teacher'] ); ?></span>
				<time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
			</div>
		</div>
	</a>
</article>
