<?php
defined( 'ABSPATH' ) || exit;

/**
 * Everything on the home page is edited from Appearance → Customize.
 * Only administrators have the edit_theme_options capability, so
 * department heads can never change the design.
 */
function atika_mod( $key ) {
	$d = atika_mod_defaults();
	return get_theme_mod( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

function atika_mod_defaults() {
	return array(
		'hero_eyebrow'   => 'مدرسة عاتكة بنت عبدالمطلب المتوسطة للبنات',
		'hero_title'     => 'منصة *إنجازات* المعلمات',
		'hero_text'      => 'مساحة واحدة توثّق فيها أقسام المدرسة إنجازات معلماتها في الأنشطة والدروس وبرامج القيم، بالصور والوصف، لتبقى جهود المدرسة حاضرة ومرتبة لكل من يتابعها.',
		'hero_btn'       => 'تصفّح الإنجازات',
		'show_stats'     => 1,
		'staff_show'     => 1,
		'staff_1_name'   => 'أ. سعاد الفيلكاوي',
		'staff_1_role'   => 'مديرة المدرسة',
		'staff_2_name'   => 'أ. منال منصوري',
		'staff_2_role'   => 'مديرة مساعدة',
		'staff_3_name'   => 'أ. نورة العازمي',
		'staff_3_role'   => 'مديرة مساعدة',
		'staff_4_name'   => 'أ. مريم الفيلكاوي',
		'staff_4_role'   => 'رئيسة القسم',
		'staff_5_name'   => '',
		'staff_5_role'   => '',
		'team_show'      => 1,
		'team_title'     => 'فريق العمل',
		'team_sub'       => 'القائمون على إعداد المنصة وإدارتها',
		'team_admin_label' => 'إدارة الموقع',
		'team_admin'     => 'أ. منى العازمي',
		'team_members_label' => 'فريق العمل',
		'team_members'   => "عذاري العازمي\nنورا العجمي\nهيفاء العازمي\nمنيرة الهاجري",
		'sections_title' => 'محاور الإنجاز',
		'sections_sub'   => 'اختاري المحور لعرض إنجازاته',
		'subjects_show'  => 1,
		'subjects_title' => 'الأقسام والمواد',
		'subjects_sub'   => 'كل قسم تديره رئيسته وتنشر إنجازات معلماته',
		'latest_title'   => 'أحدث الإنجازات',
		'latest_count'   => 9,
		'footer_about'   => 'منصة توثيق إنجازات معلمات مدرسة عاتكة بنت عبدالمطلب المتوسطة للبنات.',
		'footer_phone'   => '',
		'footer_email'   => '',
		'footer_address' => 'دولة الكويت',
		'footer_instagram' => '',
		'footer_x'       => '',
		'footer_copy'    => '© {year} مدرسة عاتكة بنت عبدالمطلب المتوسطة للبنات',
	);
}

add_action( 'customize_register', function ( WP_Customize_Manager $c ) {
	$d = atika_mod_defaults();

	$c->add_panel( 'atika_home', array( 'title' => 'الصفحة الرئيسية (عاتكة)', 'priority' => 25 ) );

	$text = function ( $section, $key, $label, $type = 'text', $desc = '' ) use ( $c, $d ) {
		$c->add_setting( $key, array(
			'default'           => $d[ $key ],
			'sanitize_callback' => 'textarea' === $type ? 'sanitize_textarea_field' : ( 'email' === $type ? 'sanitize_email' : ( 'url' === $type ? 'esc_url_raw' : 'sanitize_text_field' ) ),
			'transport'         => 'refresh',
		) );
		$c->add_control( $key, array( 'section' => $section, 'label' => $label, 'type' => $type, 'description' => $desc ) );
	};
	$check = function ( $section, $key, $label ) use ( $c, $d ) {
		$c->add_setting( $key, array( 'default' => $d[ $key ], 'sanitize_callback' => function ( $v ) { return $v ? 1 : 0; } ) );
		$c->add_control( $key, array( 'section' => $section, 'label' => $label, 'type' => 'checkbox' ) );
	};

	// Hero
	$c->add_section( 'atika_hero', array( 'title' => 'الواجهة', 'panel' => 'atika_home' ) );
	$text( 'atika_hero', 'hero_eyebrow', 'السطر الصغير فوق العنوان' );
	$text( 'atika_hero', 'hero_title', 'العنوان الرئيسي', 'text', 'ضعي الكلمة المميزة بين نجمتين: منصة *إنجازات* المعلمات' );
	$text( 'atika_hero', 'hero_text', 'النص التعريفي', 'textarea' );
	$text( 'atika_hero', 'hero_btn', 'نص الزر' );
	$check( 'atika_hero', 'show_stats', 'إظهار الأرقام (الإنجازات، المعلمات، الصور)' );

	// Staff
	$c->add_section( 'atika_staff', array( 'title' => 'إدارة المدرسة', 'panel' => 'atika_home' ) );
	$check( 'atika_staff', 'staff_show', 'إظهار قسم الإدارة' );
	for ( $i = 1; $i <= 5; $i++ ) {
		$text( 'atika_staff', "staff_{$i}_name", 'الاسم ' . $i, 'text', 1 === $i ? 'الاسم الأول يظهر بشكل مميز (المديرة). اتركي الاسم فارغاً لإخفاء البطاقة.' : '' );
		$text( 'atika_staff', "staff_{$i}_role", 'المسمى ' . $i );
	}

	// Team
	$c->add_section( 'atika_team', array( 'title' => 'فريق العمل', 'panel' => 'atika_home', 'description' => 'خانة قابلة للتوسيع في الصفحة الرئيسية.' ) );
	$check( 'atika_team', 'team_show', 'إظهار خانة فريق العمل' );
	$text( 'atika_team', 'team_title', 'عنوان الخانة' );
	$text( 'atika_team', 'team_sub', 'السطر الوصفي' );
	$text( 'atika_team', 'team_admin_label', 'عنوان إدارة الموقع' );
	$text( 'atika_team', 'team_admin', 'إدارة الموقع', 'textarea', 'اسم في كل سطر' );
	$text( 'atika_team', 'team_members_label', 'عنوان الفريق' );
	$text( 'atika_team', 'team_members', 'أعضاء الفريق', 'textarea', 'اسم في كل سطر' );

	// Sections & subjects
	$c->add_section( 'atika_blocks', array( 'title' => 'المحاور والمواد والإنجازات', 'panel' => 'atika_home', 'description' => 'لإضافة محور أو تعديل اسمه ولونه: الإنجازات ← المحاور.' ) );
	$text( 'atika_blocks', 'sections_title', 'عنوان المحاور' );
	$text( 'atika_blocks', 'sections_sub', 'وصف المحاور' );
	$check( 'atika_blocks', 'subjects_show', 'إظهار قسم المواد الدراسية' );
	$text( 'atika_blocks', 'subjects_title', 'عنوان المواد' );
	$text( 'atika_blocks', 'subjects_sub', 'وصف المواد' );
	$text( 'atika_blocks', 'latest_title', 'عنوان أحدث الإنجازات' );
	$c->add_setting( 'latest_count', array( 'default' => 9, 'sanitize_callback' => 'absint' ) );
	$c->add_control( 'latest_count', array( 'section' => 'atika_blocks', 'label' => 'عدد الإنجازات المعروضة', 'type' => 'select', 'choices' => array( 3 => '٣', 6 => '٦', 9 => '٩', 12 => '١٢' ) ) );

	// Footer
	$c->add_section( 'atika_footer', array( 'title' => 'التذييل والتواصل', 'panel' => 'atika_home' ) );
	$text( 'atika_footer', 'footer_about', 'نبذة', 'textarea' );
	$text( 'atika_footer', 'footer_phone', 'الهاتف' );
	$text( 'atika_footer', 'footer_email', 'البريد', 'email' );
	$text( 'atika_footer', 'footer_address', 'العنوان' );
	$text( 'atika_footer', 'footer_instagram', 'رابط إنستغرام', 'url' );
	$text( 'atika_footer', 'footer_x', 'رابط X', 'url' );
	$text( 'atika_footer', 'footer_copy', 'سطر الحقوق', 'text', '{year} تُستبدل بالسنة الحالية' );

	// Colors
	$colors = array( 'atika_color_navy' => array( 'الكحلي (الأساسي)', '#1b2242' ), 'atika_color_green' => array( 'الأخضر', '#037b3e' ), 'atika_color_maroon' => array( 'العنابي', '#7a2934' ) );
	foreach ( $colors as $k => $v ) {
		$c->add_setting( $k, array( 'default' => $v[1], 'sanitize_callback' => 'sanitize_hex_color' ) );
		$c->add_control( new WP_Customize_Color_Control( $c, $k, array( 'section' => 'colors', 'label' => $v[0] ) ) );
	}
} );
