</main>
<footer class="site-footer">
	<div class="wrap foot-grid">
		<div class="foot-brand">
			<img src="<?php echo esc_url( atika_theme_logo_url() ); ?>" alt="" width="200" height="75" loading="lazy">
			<p><?php echo esc_html( atika_mod( 'footer_about' ) ); ?></p>
		</div>
		<div>
			<h3>روابط</h3>
			<ul class="foot-links">
				<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">الرئيسية</a></li>
				<?php if ( atika_has_core() ) : ?>
					<li><a href="<?php echo esc_url( get_post_type_archive_link( ATIKA_CPT ) ); ?>">كل الإنجازات</a></li>
					<li><a href="<?php echo esc_url( atika_page_url( 'login' ) ); ?>">دخول رئيسات الأقسام</a></li>
				<?php endif; ?>
			</ul>
		</div>
		<?php
		$phone = atika_mod( 'footer_phone' );
		$email = atika_mod( 'footer_email' );
		$addr  = atika_mod( 'footer_address' );
		$ig    = atika_mod( 'footer_instagram' );
		$x     = atika_mod( 'footer_x' );
		if ( $phone || $email || $addr || $ig || $x ) :
			?>
			<div>
				<h3>تواصل</h3>
				<ul class="foot-contact">
					<?php if ( $phone ) : ?><li><?php echo atika_svg( 'phone' ); // phpcs:ignore ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>" dir="ltr"><?php echo esc_html( $phone ); ?></a></li><?php endif; ?>
					<?php if ( $email ) : ?><li><?php echo atika_svg( 'mail' ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( $email ); ?>" dir="ltr"><?php echo esc_html( $email ); ?></a></li><?php endif; ?>
					<?php if ( $addr ) : ?><li><?php echo atika_svg( 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( $addr ); ?></span></li><?php endif; ?>
				</ul>
				<?php if ( $ig || $x ) : ?>
					<div class="socials">
						<?php if ( $ig ) : ?><a href="<?php echo esc_url( $ig ); ?>" target="_blank" rel="noopener" aria-label="إنستغرام"><?php echo atika_svg( 'instagram' ); // phpcs:ignore ?></a><?php endif; ?>
						<?php if ( $x ) : ?><a href="<?php echo esc_url( $x ); ?>" target="_blank" rel="noopener" aria-label="X"><?php echo atika_svg( 'x' ); // phpcs:ignore ?></a><?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
	<div class="wrap foot-copy"><?php echo esc_html( str_replace( '{year}', atika_num( wp_date( 'Y' ) ), atika_mod( 'footer_copy' ) ) ); ?></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
