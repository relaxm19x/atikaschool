<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="wrap block">
	<h1 class="page-title"><?php echo is_search() ? 'نتائج البحث: ' . esc_html( get_search_query() ) : esc_html( wp_strip_all_tags( get_the_archive_title() ? get_the_archive_title() : get_bloginfo( 'name' ) ) ); ?></h1>
	<?php if ( have_posts() ) : ?>
		<div class="posts">
			<?php while ( have_posts() ) : the_post(); ?>
				<article class="post-row">
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 30 ) ); ?></p>
				</article>
			<?php endwhile; ?>
		</div>
		<?php atika_pagination(); ?>
	<?php else : ?>
		<div class="empty"><h3>لا يوجد محتوى</h3></div>
	<?php endif; ?>
</div>
<?php
get_footer();
