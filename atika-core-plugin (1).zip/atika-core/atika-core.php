<?php
/**
 * Plugin Name:       منصة إنجازات عاتكة
 * Description:       نظام رئيسات الأقسام لمدرسة عاتكة بنت عبدالمطلب: تسجيل مع توثيق البريد، اعتماد الإدارة، لوحة تحكم خاصة بكل مادة، ونشر إنجازات المعلمات بالصور.
 * Version:           1.2.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Add More Q8
 * Text Domain:       atika-core
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'ATIKA_VERSION', '1.2.0' );
define( 'ATIKA_FILE', __FILE__ );
define( 'ATIKA_DIR', plugin_dir_path( __FILE__ ) );
define( 'ATIKA_URL', plugin_dir_url( __FILE__ ) );

define( 'ATIKA_CPT', 'atika_achievement' );
define( 'ATIKA_TAX_SECTION', 'atika_section' );
define( 'ATIKA_TAX_SUBJECT', 'atika_subject' );
define( 'ATIKA_ROLE', 'dept_head' );

require_once ATIKA_DIR . 'includes/helpers.php';
require_once ATIKA_DIR . 'includes/cpt.php';
require_once ATIKA_DIR . 'includes/mail.php';
require_once ATIKA_DIR . 'includes/auth.php';
require_once ATIKA_DIR . 'includes/dashboard.php';
require_once ATIKA_DIR . 'includes/admin.php';

register_activation_hook( __FILE__, 'atika_activate' );
register_deactivation_hook( __FILE__, 'atika_deactivate' );

function atika_activate() {
	atika_register_role();
	atika_register_content_types();
	atika_seed_sections();
	atika_create_pages();

	if ( false === get_option( 'atika_settings' ) ) {
		add_option( 'atika_settings', atika_default_settings() );
	}
	atika_clean_fresh_install();
	atika_create_team_accounts();
	update_option( 'atika_db_version', ATIKA_VERSION );
	if ( ! wp_next_scheduled( 'atika_cleanup_unverified' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'atika_cleanup_unverified' );
	}
	flush_rewrite_rules();
}

function atika_deactivate() {
	wp_clear_scheduled_hook( 'atika_cleanup_unverified' );
	flush_rewrite_rules();
}

/**
 * Role for department heads. They get no editing capability inside wp-admin;
 * everything they do goes through the front-end dashboard, which checks
 * ownership of every achievement itself.
 */
function atika_register_role() {
	if ( ! get_role( ATIKA_ROLE ) ) {
		add_role( ATIKA_ROLE, 'رئيسة قسم', array( 'read' => true, 'upload_files' => true ) );
	}
	if ( ! get_role( ATIKA_TEAM_ROLE ) ) {
		add_role( ATIKA_TEAM_ROLE, 'عضو فريق العمل', array( 'read' => true, 'upload_files' => true ) );
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( atika_cpt_caps() as $cap ) {
			$admin->add_cap( $cap );
		}
	}
}

/** Pages the system needs. Created once and remembered by ID. */
function atika_create_pages() {
	$pages = array(
		'register'  => array( 'تسجيل رئيسة قسم', 'head-register', '[atika_register]' ),
		'login'     => array( 'دخول رئيسات الأقسام', 'head-login', '[atika_login]' ),
		'dashboard' => array( 'لوحة التحكم', 'head-dashboard', '[atika_dashboard]' ),
	);
	$ids = get_option( 'atika_pages', array() );
	foreach ( $pages as $key => $p ) {
		if ( ! empty( $ids[ $key ] ) && get_post( $ids[ $key ] ) && 'trash' !== get_post_status( $ids[ $key ] ) ) {
			continue;
		}
		// Reuse a page that already carries our shortcode (e.g. after re-activation) instead of making a duplicate.
		$existing = get_posts( array(
			'post_type'   => 'page',
			'post_status' => array( 'publish', 'draft', 'private' ),
			's'           => $p[2],
			'numberposts' => 1,
			'orderby'     => 'ID',
			'order'       => 'ASC',
			'fields'      => 'ids',
		) );
		if ( $existing && false !== strpos( get_post_field( 'post_content', $existing[0] ), $p[2] ) ) {
			$ids[ $key ] = (int) $existing[0];
			continue;
		}
		$ids[ $key ] = wp_insert_post( array(
			'post_title'   => $p[0],
			'post_name'    => $p[1],
			'post_content' => $p[2],
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'comment_status' => 'closed',
		) );
	}
	update_option( 'atika_pages', $ids );
	atika_create_privacy_page();
}

/** Arabic privacy policy, set as the site's official privacy page (admin can edit it). */
function atika_create_privacy_page() {
	if ( get_option( 'atika_privacy_created' ) ) {
		return;
	}
	$site    = get_bloginfo( 'name' );
	$content = '<!-- wp:paragraph --><p>توضح هذه السياسة كيف تتعامل منصة ' . esc_html( $site ) . ' مع البيانات الشخصية.</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading --><h2>البيانات التي نجمعها</h2><!-- /wp:heading -->'
		. '<!-- wp:list --><ul><li>عند تسجيل رئيسة القسم: الاسم الكامل، البريد الإلكتروني، رقم الجوال، واسم المادة.</li><li>محتوى الإنجازات المنشورة: العنوان والوصف واسم المعلمة والصور.</li><li>بيانات تقنية ضرورية لتسجيل الدخول وحماية الحساب، مثل ملفات تعريف الارتباط الخاصة بالجلسة.</li></ul><!-- /wp:list -->'
		. '<!-- wp:heading --><h2>كيف نستخدم البيانات</h2><!-- /wp:heading -->'
		. '<!-- wp:list --><ul><li>إنشاء الحساب وتوثيق البريد الإلكتروني واعتماده من إدارة المدرسة.</li><li>إرسال رسائل الحساب، مثل التوثيق والاعتماد وإعادة تعيين كلمة المرور.</li><li>عرض إنجازات المعلمات للزوار على الموقع.</li></ul><!-- /wp:list -->'
		. '<!-- wp:paragraph --><p>لا يظهر البريد الإلكتروني ولا رقم الجوال للزوار، ولا تُشارك البيانات مع أي جهة خارجية أو تُستخدم لأغراض تسويقية.</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading --><h2>حقوقك</h2><!-- /wp:heading -->'
		. '<!-- wp:paragraph --><p>يمكنك تعديل بياناتك من صفحة «حسابي» في لوحة التحكم، أو طلب حذف حسابك وبياناته بالتواصل مع إدارة الموقع.</p><!-- /wp:paragraph -->';
	$id = wp_insert_post( array(
		'post_title'   => 'سياسة الخصوصية',
		'post_name'    => 'privacy',
		'post_content' => $content,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'comment_status' => 'closed',
	) );
	if ( $id && ! is_wp_error( $id ) ) {
		$old = (int) get_option( 'wp_page_for_privacy_policy' );
		if ( $old && 'draft' === get_post_status( $old ) ) {
			wp_delete_post( $old, true ); // WordPress's empty English draft.
		}
		update_option( 'wp_page_for_privacy_policy', $id );
		update_option( 'atika_privacy_created', 1 );
	}
}

add_action( 'init', 'atika_maybe_upgrade', 20 );
function atika_maybe_upgrade() {
	if ( get_option( 'atika_db_version' ) !== ATIKA_VERSION ) {
		atika_register_role();
		// Lock so two simultaneous first requests cannot run the setup twice.
		if ( ! add_option( 'atika_upgrade_lock', time(), '', 'no' ) ) {
			if ( (int) get_option( 'atika_upgrade_lock' ) > time() - 60 ) {
				return;
			}
			update_option( 'atika_upgrade_lock', time(), 'no' );
		}
		update_option( 'atika_db_version', ATIKA_VERSION );
		atika_create_pages();
		atika_create_team_accounts();
		delete_option( 'atika_upgrade_lock' );
	}
}

/**
 * A fresh WordPress ships with "Hello world!", a "Sample Page" and a demo comment.
 * Remove them (only if nobody edited them) and set sensible Kuwait defaults.
 */
function atika_clean_fresh_install() {
	foreach ( array( array( 'hello-world', 'post' ), array( 'sample-page', 'page' ) ) as $it ) {
		$p = get_page_by_path( $it[0], OBJECT, $it[1] );
		if ( $p && $p->post_date === $p->post_modified ) {
			wp_delete_post( $p->ID, true );
		}
	}
	if ( ! get_option( 'timezone_string' ) && 0 == get_option( 'gmt_offset' ) ) { // phpcs:ignore
		update_option( 'timezone_string', 'Asia/Kuwait' );
	}
	$tag = get_option( 'blogdescription' );
	if ( '' === $tag || 'Just another WordPress site' === $tag || 'موقع ووردبريس عربي آخر' === $tag || false !== strpos( $tag, 'WordPress' ) ) {
		update_option( 'blogdescription', 'منصة إنجازات المعلمات' );
	}
	update_option( 'default_comment_status', 'closed' );
	update_option( 'default_ping_status', 'closed' );
}

/**
 * The team's login accounts. Created once; never overwritten, so passwords
 * changed later by the members stay as they set them.
 * Only password hashes are stored here, never the passwords themselves.
 */
function atika_create_team_accounts() {
	global $wpdb;
	$accounts = array(
		array( 'mona.alazmi', 'أ. منى العازمي', 'administrator', '$P$BliH6TY0g5xmdK.DCoYku.4x.bnn65/' ),
		array( 'athari.alazmi', 'عذاري العازمي', ATIKA_TEAM_ROLE, '$P$BOu9jhP0s43kPI05r7a9TX.fJCxyBm.' ),
		array( 'noura.alajmi', 'نورا العجمي', ATIKA_TEAM_ROLE, '$P$BcnWYQoZAJET6c5hCBLC7JvyC7YFQv/' ),
		array( 'munira.alhajri', 'منيرة الهاجري', ATIKA_TEAM_ROLE, '$P$BnSbo0xjYrMp4VVi2R87eQ5sZYH0BV/' ),
	);
	foreach ( $accounts as $a ) {
		if ( username_exists( $a[0] ) ) {
			continue;
		}
		$parts = explode( ' ', preg_replace( '/^أ\.\s*/u', '', $a[1] ), 2 );
		$id    = wp_insert_user( array(
			'user_login'           => $a[0],
			'user_pass'            => wp_generate_password( 32 ),
			'display_name'         => $a[1],
			'nickname'             => $a[1],
			'first_name'           => $parts[0],
			'last_name'            => isset( $parts[1] ) ? $parts[1] : '',
			'role'                 => $a[2],
			'show_admin_bar_front' => 'false',
		) );
		if ( ! is_wp_error( $id ) ) {
			$wpdb->update( $wpdb->users, array( 'user_pass' => $a[3] ), array( 'ID' => $id ) );
			clean_user_cache( $id );
		}
	}
}
