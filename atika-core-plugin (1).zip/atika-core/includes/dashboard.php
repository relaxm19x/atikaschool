<?php
defined( 'ABSPATH' ) || exit;

/* ======================================================================
 * Access + POST handling
 * ==================================================================== */

add_action( 'template_redirect', 'atika_dashboard_gate', 6 );
function atika_dashboard_gate() {
	if ( ! is_page() || get_queried_object_id() !== atika_page_id( 'dashboard' ) ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		wp_safe_redirect( atika_page_url( 'login' ) );
		exit;
	}
	if ( ! atika_can_publish() && ! atika_is_head() ) {
		return; // Shortcode shows a short notice.
	}
	if ( atika_is_head() && ATIKA_STATUS_ACTIVE !== atika_head_status( get_current_user_id() ) ) {
		wp_logout();
		wp_safe_redirect( atika_page_url( 'login' ) );
		exit;
	}
	if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && ! empty( $_POST['atika_dash'] ) ) {
		$a = sanitize_key( wp_unslash( $_POST['atika_dash'] ) );
		switch ( $a ) {
			case 'save':
				atika_dash_save();
				break;
			case 'delete':
				atika_dash_delete();
				break;
			case 'teacher_add':
			case 'teacher_remove':
				atika_dash_teachers( $a );
				break;
			case 'profile':
				atika_dash_profile();
				break;
			case 'password':
				atika_dash_password();
				break;
		}
	}
}

function atika_dash_url( $args = array() ) {
	return atika_page_url( 'dashboard', $args );
}

/** Achievement the current user may edit (her own; the site admin may edit all), or null. */
function atika_own_post( $id ) {
	$p = $id ? get_post( $id ) : null;
	if ( ! $p || ATIKA_CPT !== $p->post_type ) {
		return null;
	}
	if ( (int) $p->post_author !== get_current_user_id() && ! atika_is_site_admin() ) {
		return null;
	}
	if ( ! in_array( $p->post_status, array( 'publish', 'draft' ), true ) ) {
		return null;
	}
	return $p;
}

function atika_head_teachers( $user_id ) {
	$list = get_user_meta( $user_id, 'atika_teachers', true );
	$list = is_array( $list ) ? $list : array();
	natcasesort( $list );
	return array_values( array_unique( array_filter( $list ) ) );
}

function atika_add_teacher_name( $user_id, $name ) {
	$list = atika_head_teachers( $user_id );
	if ( $name && ! in_array( $name, $list, true ) ) {
		$list[] = $name;
		update_user_meta( $user_id, 'atika_teachers', $list );
	}
}

/* ---------------- Save achievement ---------------- */

function atika_dash_save() {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_save' ) ) {
		atika_err( 'form', 'انتهت صلاحية الصفحة. احفظي النص في مكان آخر، حدّثي الصفحة وأعيدي المحاولة.' );
		return;
	}
	$uid  = get_current_user_id();
	$id   = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	$post = $id ? atika_own_post( $id ) : null;
	if ( $id && ! $post ) {
		wp_die( 'لا تملكين صلاحية تعديل هذا الإنجاز.', 403 );
	}
	$is_head    = atika_is_head();
	$subject_id = 0;
	if ( $is_head ) {
		$subject_id = atika_head_subject_id( $uid );
		if ( ! $subject_id ) {
			$subject_id = atika_assign_subject( $uid );
		}
	}
	$subject_in = atika_clean_subject( isset( $_POST['subject'] ) ? $_POST['subject'] : '' );

	$title   = sanitize_text_field( wp_unslash( isset( $_POST['title'] ) ? $_POST['title'] : '' ) );
	$teacher = preg_replace( '/\s+/u', ' ', sanitize_text_field( wp_unslash( isset( $_POST['teacher'] ) ? $_POST['teacher'] : '' ) ) );
	$section = isset( $_POST['section'] ) ? absint( $_POST['section'] ) : 0;
	$date    = sanitize_text_field( wp_unslash( isset( $_POST['date'] ) ? $_POST['date'] : '' ) );
	$desc    = sanitize_textarea_field( wp_unslash( isset( $_POST['description'] ) ? $_POST['description'] : '' ) );
	$status  = ( isset( $_POST['status'] ) && 'draft' === $_POST['status'] ) ? 'draft' : 'publish';
	$remove  = isset( $_POST['remove_images'] ) ? array_map( 'absint', (array) $_POST['remove_images'] ) : array();
	$cover   = isset( $_POST['cover'] ) ? absint( $_POST['cover'] ) : 0;

	$GLOBALS['atika_form_old'] = compact( 'title', 'teacher', 'section', 'date', 'desc', 'status', 'subject_in' );
	if ( ! $is_head && ( mb_strlen( $subject_in ) < 2 || mb_strlen( $subject_in ) > 60 ) ) {
		atika_err( 'subject', 'اكتبي اسم المادة أو اختاريها من القائمة.' );
	}

	if ( mb_strlen( $title ) < 3 ) {
		atika_err( 'title', 'اكتبي عنواناً واضحاً للإنجاز.' );
	}
	if ( mb_strlen( $teacher ) < 3 ) {
		atika_err( 'teacher', 'اكتبي اسم المعلمة صاحبة الإنجاز.' );
	}
	$sec_term = $section ? get_term( $section, ATIKA_TAX_SECTION ) : null;
	if ( ! $sec_term || is_wp_error( $sec_term ) ) {
		atika_err( 'section', 'اختاري محور الإنجاز.' );
	}
	$ts = $date ? strtotime( $date . ' 12:00:00' ) : current_time( 'timestamp' );
	if ( ! $ts || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ? $date : gmdate( 'Y-m-d' ) ) ) {
		atika_err( 'date', 'التاريخ غير صحيح.' );
	} elseif ( $ts > current_time( 'timestamp' ) + DAY_IN_SECONDS ) {
		atika_err( 'date', 'لا يمكن أن يكون تاريخ الإنجاز في المستقبل.' );
	}
	if ( mb_strlen( $desc ) < 10 ) {
		atika_err( 'description', 'اكتبي وصفاً للإنجاز (١٠ أحرف على الأقل).' );
	}

	// Existing images that stay.
	$keep = $post ? array_values( array_diff( atika_gallery_ids( $post->ID ), $remove ) ) : array();

	// Validate new uploads before touching anything.
	$files   = atika_collect_files( 'images' );
	$max_n   = (int) atika_setting( 'max_images' );
	$max_b   = (int) atika_setting( 'max_image_mb' ) * MB_IN_BYTES;
	$allowed = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif', 'heic' => 'image/heic' );
	foreach ( $files as $f ) {
		if ( UPLOAD_ERR_OK !== $f['error'] ) {
			atika_err( 'images', 'تعذّر رفع الصورة «' . $f['name'] . '». قد يكون حجمها أكبر من المسموح في الاستضافة.' );
			break;
		}
		if ( $f['size'] > $max_b ) {
			atika_err( 'images', 'الصورة «' . $f['name'] . '» أكبر من ' . atika_ar_num( (int) atika_setting( 'max_image_mb' ) ) . ' ميغابايت.' );
			break;
		}
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $allowed );
		if ( empty( $check['type'] ) ) {
			atika_err( 'images', 'الملف «' . $f['name'] . '» ليس صورة مدعومة. استخدمي JPG أو PNG أو WEBP.' );
			break;
		}
	}
	if ( count( $keep ) + count( $files ) > $max_n ) {
		atika_err( 'images', 'الحد الأقصى ' . atika_ar_num( $max_n ) . ' صور لكل إنجاز.' );
	}
	if ( 'publish' === $status && 0 === count( $keep ) + count( $files ) && empty( $GLOBALS['atika_form_errors']['images'] ) ) {
		atika_err( 'images', 'أضيفي صورة واحدة على الأقل قبل النشر، أو احفظي الإنجاز كمسودة.' );
	}
	if ( $GLOBALS['atika_form_errors'] ) {
		if ( $files ) {
			$GLOBALS['atika_files_lost'] = true;
		}
		return;
	}

	// Never let a chosen date land in the future, or WordPress would schedule the post instead of publishing it.
	$now_local = current_time( 'mysql' );
	$local     = ( ! $date || $date === current_time( 'Y-m-d' ) ) ? $now_local : $date . ' 12:00:00';
	if ( $post && $date && $date === get_the_date( 'Y-m-d', $post ) ) {
		$local = $post->post_date; // date unchanged: keep the original time.
	}
	if ( $local > $now_local ) {
		$local = $now_local;
	}
	$postarr = array(
		'post_type'     => ATIKA_CPT,
		'post_title'    => $title,
		'post_content'  => $desc,
		'post_status'   => $status,
		'post_author'   => $post ? (int) $post->post_author : $uid,
		'post_date'     => $local,
		'post_date_gmt' => get_gmt_from_date( $local ),
		'edit_date'     => true,
	);
	if ( $post ) {
		$postarr['ID'] = $post->ID;
		$pid           = wp_update_post( wp_slash( $postarr ), true );
	} else {
		$pid = wp_insert_post( wp_slash( $postarr ), true );
	}
	if ( is_wp_error( $pid ) ) {
		atika_err( 'form', 'تعذّر الحفظ: ' . $pid->get_error_message() );
		return;
	}

	wp_set_object_terms( $pid, array( (int) $sec_term->term_id ), ATIKA_TAX_SECTION, false );
	if ( ! $is_head ) {
		$subject_id = atika_find_or_create_subject( $subject_in );
	}
	if ( $subject_id ) {
		wp_set_object_terms( $pid, array( (int) $subject_id ), ATIKA_TAX_SUBJECT, false );
	}
	update_post_meta( $pid, 'atika_teacher', $teacher );
	atika_add_teacher_name( $uid, $teacher );

	// Remove images she unticked (only ones attached to this achievement).
	foreach ( $remove as $aid ) {
		if ( $post && (int) get_post_field( 'post_parent', $aid ) === (int) $pid ) {
			wp_delete_attachment( $aid, true );
		}
	}

	// Upload new images.
	$upload_fail = 0;
	if ( $files ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		foreach ( $files as $f ) {
			$aid = media_handle_sideload( $f, $pid, $title, array( 'post_author' => $uid ) );
			if ( is_wp_error( $aid ) ) {
				$upload_fail++;
			} else {
				$keep[] = (int) $aid;
			}
		}
	}
	$keep = array_values( array_unique( array_filter( $keep ) ) );
	update_post_meta( $pid, 'atika_gallery', $keep );

	if ( $cover && in_array( $cover, $keep, true ) ) {
		set_post_thumbnail( $pid, $cover );
	} elseif ( $keep && ! in_array( (int) get_post_thumbnail_id( $pid ), $keep, true ) ) {
		set_post_thumbnail( $pid, $keep[0] );
	} elseif ( ! $keep ) {
		delete_post_thumbnail( $pid );
	}

	if ( $upload_fail ) {
		atika_flash( 'تم الحفظ، لكن تعذّر رفع ' . atika_ar_num( $upload_fail ) . ' صورة. جرّبي رفعها مرة أخرى من التعديل.', 'error' );
	} else {
		atika_flash( 'publish' === $status ? ( $post ? 'تم تحديث الإنجاز.' : 'تم نشر الإنجاز على الموقع.' ) : 'تم حفظ الإنجاز كمسودة. لن يظهر للزوار حتى تنشريه.' );
	}
	wp_safe_redirect( atika_dash_url() );
	exit;
}

/** Subject term matching what the member typed ("رياضيات" = "الرياضيات"), created if new. */
function atika_find_or_create_subject( $name ) {
	$key   = atika_subject_key( $name );
	$terms = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => false ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			if ( atika_subject_key( $t->name ) === $key ) {
				return (int) $t->term_id;
			}
		}
	}
	$r = wp_insert_term( $name, ATIKA_TAX_SUBJECT, array( 'slug' => atika_unique_term_slug( $name ) ) );
	return is_wp_error( $r ) ? 0 : (int) $r['term_id'];
}

function atika_subject_names() {
	$terms = get_terms( array( 'taxonomy' => ATIKA_TAX_SUBJECT, 'hide_empty' => false, 'orderby' => 'name' ) );
	return is_wp_error( $terms ) ? array() : wp_list_pluck( $terms, 'name' );
}

/** Normalise $_FILES[key][] into a list of single-file arrays. */
function atika_collect_files( $key ) {
	if ( empty( $_FILES[ $key ] ) || ! is_array( $_FILES[ $key ]['name'] ) ) {
		return array();
	}
	$out = array();
	$raw = $_FILES[ $key ]; // phpcs:ignore -- validated per file below.
	foreach ( $raw['name'] as $i => $name ) {
		if ( UPLOAD_ERR_NO_FILE === (int) $raw['error'][ $i ] || '' === $name ) {
			continue;
		}
		$out[] = array(
			'name'     => sanitize_file_name( $name ),
			'type'     => $raw['type'][ $i ],
			'tmp_name' => $raw['tmp_name'][ $i ],
			'error'    => (int) $raw['error'][ $i ],
			'size'     => (int) $raw['size'][ $i ],
		);
	}
	return $out;
}

/* ---------------- Delete ---------------- */

function atika_dash_delete() {
	$id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_delete_' . $id ) ) {
		wp_die( 'انتهت صلاحية الطلب.', 403 );
	}
	if ( ! atika_own_post( $id ) ) {
		wp_die( 'لا تملكين صلاحية حذف هذا الإنجاز.', 403 );
	}
	wp_delete_post( $id, true );
	atika_flash( 'تم حذف الإنجاز وصوره.' );
	wp_safe_redirect( atika_dash_url() );
	exit;
}

/* ---------------- Teachers ---------------- */

function atika_dash_teachers( $a ) {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_teachers' ) ) {
		wp_die( 'انتهت صلاحية الطلب.', 403 );
	}
	$uid  = get_current_user_id();
	$name = preg_replace( '/\s+/u', ' ', sanitize_text_field( wp_unslash( isset( $_POST['teacher'] ) ? $_POST['teacher'] : '' ) ) );
	if ( 'teacher_add' === $a ) {
		if ( mb_strlen( $name ) < 3 ) {
			atika_flash( 'اكتبي اسم المعلمة كاملاً.', 'error' );
		} else {
			atika_add_teacher_name( $uid, $name );
			atika_flash( 'تمت إضافة المعلمة ' . $name . ' إلى قسمك.' );
		}
	} else {
		$list = array_values( array_diff( atika_head_teachers( $uid ), array( $name ) ) );
		update_user_meta( $uid, 'atika_teachers', $list );
		atika_flash( 'تمت إزالة ' . $name . ' من القائمة. إنجازاتها المنشورة تبقى كما هي.' );
	}
	wp_safe_redirect( atika_dash_url( array( 'view' => 'teachers' ) ) );
	exit;
}

/* ---------------- Profile ---------------- */

function atika_dash_profile() {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_profile' ) ) {
		wp_die( 'انتهت صلاحية الطلب.', 403 );
	}
	$uid     = get_current_user_id();
	$name    = sanitize_text_field( wp_unslash( isset( $_POST['full_name'] ) ? $_POST['full_name'] : '' ) );
	$phone   = preg_replace( '/[^0-9+ ]/', '', sanitize_text_field( wp_unslash( isset( $_POST['phone'] ) ? $_POST['phone'] : '' ) ) );
	$subject = atika_clean_subject( isset( $_POST['subject'] ) ? $_POST['subject'] : '' );

	if ( mb_strlen( $name ) < 5 ) {
		atika_err( 'full_name', 'اكتبي الاسم الثنائي على الأقل.' );
	}
	$is_head = atika_is_head();
	if ( ! $is_head ) {
		// Team members have no subject of their own.
	} elseif ( mb_strlen( $subject ) < 2 || mb_strlen( $subject ) > 60 ) {
		atika_err( 'subject', 'اكتبي اسم المادة.' );
	} elseif ( atika_subject_taken_by( $subject, $uid ) ) {
		atika_err( 'subject', 'هذا الاسم مستخدم لمادة رئيسة قسم أخرى.' );
	}
	if ( $GLOBALS['atika_form_errors'] ) {
		$GLOBALS['atika_view'] = 'profile';
		return;
	}
	if ( ! $is_head && isset( $_POST['email'] ) ) {
		$email = sanitize_email( wp_unslash( $_POST['email'] ) );
		$owner = $email ? email_exists( $email ) : false;
		if ( $email && ! is_email( $email ) ) {
			atika_err( 'email', 'البريد الإلكتروني غير صحيح.' );
		} elseif ( $owner && (int) $owner !== $uid ) {
			atika_err( 'email', 'هذا البريد مستخدم في حساب آخر.' );
		}
		if ( $GLOBALS['atika_form_errors'] ) {
			$GLOBALS['atika_view'] = 'profile';
			return;
		}
		if ( $email !== wp_get_current_user()->user_email ) {
			wp_update_user( array( 'ID' => $uid, 'user_email' => $email ) );
		}
	}
	wp_update_user( array( 'ID' => $uid, 'display_name' => $name ) );
	update_user_meta( $uid, 'atika_phone', $phone );
	$tid = $is_head ? atika_head_subject_id( $uid ) : 0;
	if ( $is_head ) {
		update_user_meta( $uid, 'atika_subject_name', $subject );
	}
	if ( $tid ) {
		wp_update_term( $tid, ATIKA_TAX_SUBJECT, array( 'name' => $subject ) );
	}
	atika_flash( 'تم حفظ بياناتك.' );
	wp_safe_redirect( atika_dash_url( array( 'view' => 'profile' ) ) );
	exit;
}

function atika_dash_password() {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_password' ) ) {
		wp_die( 'انتهت صلاحية الطلب.', 403 );
	}
	$user = wp_get_current_user();
	$cur  = isset( $_POST['current'] ) ? (string) wp_unslash( $_POST['current'] ) : ''; // phpcs:ignore
	$new  = isset( $_POST['new'] ) ? (string) wp_unslash( $_POST['new'] ) : ''; // phpcs:ignore
	$new2 = isset( $_POST['new2'] ) ? (string) wp_unslash( $_POST['new2'] ) : ''; // phpcs:ignore
	$GLOBALS['atika_view'] = 'profile';
	if ( ! wp_check_password( $cur, $user->user_pass, $user->ID ) ) {
		atika_err( 'current', 'كلمة المرور الحالية غير صحيحة.' );
	} elseif ( atika_password_problem( $new, array( strstr( $user->user_email, '@', true ) ) ) ) {
		atika_err( 'new', atika_password_problem( $new, array( strstr( $user->user_email, '@', true ) ) ) );
	} elseif ( $new !== $new2 ) {
		atika_err( 'new2', 'كلمتا المرور غير متطابقتين.' );
	}
	if ( $GLOBALS['atika_form_errors'] ) {
		return;
	}
	wp_update_user( array( 'ID' => $user->ID, 'user_pass' => $new ) );
	wp_set_auth_cookie( $user->ID, false, is_ssl() );
	atika_flash( 'تم تغيير كلمة المرور.' );
	wp_safe_redirect( atika_dash_url( array( 'view' => 'profile' ) ) );
	exit;
}

/* ======================================================================
 * Dashboard shortcode
 * ==================================================================== */

function atika_icon( $name ) {
	$p = array(
		'plus'   => '<path d="M12 5v14M5 12h14"/>',
		'grid'   => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
		'users'  => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6.5 6.5 0 0 1 3.5 6"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
		'eye'    => '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
		'edit'   => '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/>',
		'trash'  => '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
		'out'    => '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l-5-5 5-5M5 12h12"/>',
		'home'   => '<path d="M3 11 12 4l9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-9Z"/>',
		'image'  => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
	);
	return '<svg class="atk-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( isset( $p[ $name ] ) ? $p[ $name ] : '' ) . '</svg>';
}

add_shortcode( 'atika_dashboard', function () {
	if ( ! is_user_logged_in() ) {
		return '';
	}
	if ( ! atika_can_publish() ) {
		return atika_auth_shell( 'لا تملكين صلاحية', 'هذه اللوحة لأعضاء فريق العمل فقط', '<a class="atk-btn atk-btn-ghost atk-btn-block" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">تسجيل الخروج</a>' );
	}
	$is_admin = atika_is_site_admin();

	$uid  = get_current_user_id();
	$user = wp_get_current_user();
	$view = isset( $GLOBALS['atika_view'] ) ? $GLOBALS['atika_view'] : ( isset( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : 'list' );
	if ( ! empty( $GLOBALS['atika_form_old'] ) && isset( $_POST['atika_dash'] ) && 'save' === $_POST['atika_dash'] ) {
		$view = 'form';
	}
	$subject_id   = atika_head_subject_id( $uid );
	$subject_name = atika_head_subject_name( $uid );
	$subject_url  = $subject_id ? get_term_link( $subject_id, ATIKA_TAX_SUBJECT ) : '';

	ob_start();
	?>
	<div class="atk atk-dash">
		<div class="atk-dash-head">
			<div class="atk-dash-hello">
				<span class="atk-avatar"><?php echo esc_html( mb_substr( preg_replace( '/^(أ\.|د\.)\s*/u', '', $user->display_name ), 0, 1 ) ); ?></span>
				<div>
					<?php if ( atika_is_head() ) : ?>
						<div class="atk-eyebrow">رئيسة قسم</div>
						<h1><?php echo esc_html( $subject_name ); ?></h1>
						<div class="atk-muted"><?php echo esc_html( $user->display_name ); ?></div>
					<?php else : ?>
						<div class="atk-eyebrow"><?php echo $is_admin ? 'إدارة الموقع' : 'فريق العمل'; ?></div>
						<h1><?php echo esc_html( $user->display_name ); ?></h1>
						<div class="atk-muted"><?php echo $is_admin ? 'تظهر لكِ إنجازات الفريق كله' : 'لوحة نشر الإنجازات'; ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="atk-dash-actions">
				<?php if ( $subject_url && ! is_wp_error( $subject_url ) ) : ?>
					<a class="atk-btn atk-btn-ghost" href="<?php echo esc_url( $subject_url ); ?>" target="_blank" rel="noopener"><?php echo atika_icon( 'eye' ); // phpcs:ignore ?>صفحة المادة</a>
				<?php endif; ?>
				<?php if ( $is_admin ) : ?>
					<a class="atk-btn atk-btn-ghost" href="<?php echo esc_url( admin_url() ); ?>"><?php echo atika_icon( 'grid' ); // phpcs:ignore ?>لوحة ووردبريس</a>
				<?php endif; ?>
				<a class="atk-btn atk-btn-green" href="<?php echo esc_url( atika_dash_url( array( 'view' => 'form' ) ) ); ?>"><?php echo atika_icon( 'plus' ); // phpcs:ignore ?>إضافة إنجاز</a>
			</div>
		</div>

		<nav class="atk-tabs" aria-label="أقسام لوحة التحكم">
			<?php
			$tabs = array(
				'list'     => array( 'الإنجازات', 'grid' ),
				'teachers' => array( 'المعلمات', 'users' ),
				'profile'  => array( 'حسابي', 'user' ),
			);
			foreach ( $tabs as $k => $t ) {
				$on = ( $k === $view || ( 'form' === $view && 'list' === $k ) );
				echo '<a href="' . esc_url( atika_dash_url( 'list' === $k ? array() : array( 'view' => $k ) ) ) . '" class="' . ( $on ? 'on' : '' ) . '"' . ( $on ? ' aria-current="page"' : '' ) . '>' . atika_icon( $t[1] ) . esc_html( $t[0] ) . '</a>'; // phpcs:ignore
			}
			?>
			<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="atk-tab-out"><?php echo atika_icon( 'out' ); // phpcs:ignore ?>خروج</a>
		</nav>

		<?php
		$flash = atika_take_flash();
		if ( $flash ) {
			echo atika_notice( esc_html( $flash['msg'] ), $flash['type'] ); // phpcs:ignore
		}
		if ( 'form' === $view ) {
			atika_view_form( $uid );
		} elseif ( 'teachers' === $view ) {
			atika_view_teachers( $uid );
		} elseif ( 'profile' === $view ) {
			atika_view_profile( $user );
		} else {
			atika_view_list( $uid );
		}
		?>
	</div>
	<?php
	return ob_get_clean();
} );

/* ---------------- View: list ---------------- */

function atika_view_list( $uid ) {
	global $wpdb;
	$scope = atika_is_site_admin() ? '' : $uid;
	$all = get_posts( array(
		'post_type'   => ATIKA_CPT,
		'author'      => $scope,
		'post_status' => array( 'publish', 'draft' ),
		'numberposts' => -1,
		'fields'      => 'ids',
	) );
	$pub = 0;
	$imgs = 0;
	$month = 0;
	$teachers = array();
	$mstart = strtotime( gmdate( 'Y-m-01', current_time( 'timestamp' ) ) );
	foreach ( $all as $pid ) {
		if ( 'publish' === get_post_status( $pid ) ) {
			$pub++;
		}
		$imgs += count( atika_gallery_ids( $pid ) );
		$t = get_post_meta( $pid, 'atika_teacher', true );
		if ( $t ) {
			$teachers[ $t ] = true;
		}
		if ( strtotime( get_post_field( 'post_date', $pid ) ) >= $mstart ) {
			$month++;
		}
	}
	$drafts = count( $all ) - $pub;
	?>
	<div class="atk-stats">
		<div><b><?php echo esc_html( atika_ar_num( $pub ) ); ?></b><span>إنجاز منشور</span></div>
		<div><b><?php echo esc_html( atika_ar_num( $month ) ); ?></b><span>هذا الشهر</span></div>
		<div><b><?php echo esc_html( atika_ar_num( count( $teachers ) ) ); ?></b><span>معلمة مشاركة</span></div>
		<div><b><?php echo esc_html( atika_ar_num( $imgs ) ); ?></b><span>صورة</span></div>
	</div>
	<?php
	$sec  = isset( $_GET['sec'] ) ? absint( $_GET['sec'] ) : 0;
	$q    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
	$st   = isset( $_GET['st'] ) && 'draft' === $_GET['st'] ? 'draft' : '';
	$page = max( 1, isset( $_GET['pg'] ) ? absint( $_GET['pg'] ) : 1 );
	$args = array(
		'post_type'      => ATIKA_CPT,
		'author'         => $scope,
		'post_status'    => $st ? array( 'draft' ) : array( 'publish', 'draft' ),
		'posts_per_page' => 15,
		'paged'          => $page,
	);
	if ( $sec ) {
		$args['tax_query'] = array( array( 'taxonomy' => ATIKA_TAX_SECTION, 'terms' => $sec ) ); // phpcs:ignore
	}
	if ( $q ) {
		$args['s'] = $q;
	}
	$list = new WP_Query( $args );
	?>
	<form class="atk-filter" method="get" action="<?php echo esc_url( atika_dash_url() ); ?>">
		<?php if ( ! get_option( 'permalink_structure' ) ) : ?><input type="hidden" name="page_id" value="<?php echo esc_attr( atika_page_id( 'dashboard' ) ); ?>"><?php endif; ?>
		<label class="atk-search"><?php echo atika_icon( 'search' ); // phpcs:ignore ?><input type="search" name="q" id="atk-dq" value="<?php echo esc_attr( $q ); ?>" placeholder="ابحثي بالعنوان أو اسم المعلمة" aria-label="بحث"></label>
		<select name="sec" id="atk-dsec" aria-label="المحور">
			<option value="">كل المحاور</option>
			<?php foreach ( atika_get_sections() as $s ) : ?>
				<option value="<?php echo esc_attr( $s->term_id ); ?>" <?php selected( $sec, $s->term_id ); ?>><?php echo esc_html( $s->name ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php if ( $drafts ) : ?>
			<select name="st" id="atk-dst" aria-label="الحالة"><option value="">كل الحالات</option><option value="draft" <?php selected( $st, 'draft' ); ?>>المسودات (<?php echo esc_html( atika_ar_num( $drafts ) ); ?>)</option></select>
		<?php endif; ?>
		<button class="atk-btn atk-btn-ghost" type="submit">تصفية</button>
	</form>

	<?php if ( ! $list->have_posts() ) : ?>
		<div class="atk-empty">
			<?php echo atika_icon( 'image' ); // phpcs:ignore ?>
			<?php if ( $q || $sec || $st ) : ?>
				<p>لا توجد نتائج مطابقة.</p><a class="atk-btn atk-btn-ghost" href="<?php echo esc_url( atika_dash_url() ); ?>">عرض الكل</a>
			<?php else : ?>
				<h3>لم تنشري أي إنجاز بعد</h3>
				<p>ابدئي بأول إنجاز: عنوان، اسم المعلمة، المادة، المحور، وصف، وصور.</p>
				<a class="atk-btn atk-btn-green" href="<?php echo esc_url( atika_dash_url( array( 'view' => 'form' ) ) ); ?>"><?php echo atika_icon( 'plus' ); // phpcs:ignore ?>إضافة أول إنجاز</a>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="atk-items">
			<?php
			while ( $list->have_posts() ) :
				$list->the_post();
				$pid   = get_the_ID();
				$ids   = atika_gallery_ids( $pid );
				$secs  = get_the_terms( $pid, ATIKA_TAX_SECTION );
				$s     = $secs && ! is_wp_error( $secs ) ? $secs[0] : null;
				$draft = 'draft' === get_post_status();
				?>
				<article class="atk-item">
					<div class="atk-item-thumb">
						<?php echo $ids ? wp_get_attachment_image( $ids[0], 'thumbnail', false, array( 'alt' => '' ) ) : atika_icon( 'image' ); // phpcs:ignore ?>
						<?php if ( count( $ids ) > 1 ) : ?><span><?php echo esc_html( atika_ar_num( count( $ids ) ) ); ?></span><?php endif; ?>
					</div>
					<div class="atk-item-main">
						<h3><?php the_title(); ?></h3>
						<div class="atk-item-meta">
							<?php if ( $s ) : ?><span class="atk-tag" style="--c:<?php echo esc_attr( atika_section_color( $s ) ); ?>"><?php echo esc_html( $s->name ); ?></span><?php endif; ?>
							<?php $sub = get_the_terms( $pid, ATIKA_TAX_SUBJECT ); if ( $sub && ! is_wp_error( $sub ) && ! atika_is_head() ) : ?><span class="atk-tag"><?php echo esc_html( $sub[0]->name ); ?></span><?php endif; ?>
							<span><?php echo esc_html( get_post_meta( $pid, 'atika_teacher', true ) ); ?></span>
							<?php if ( atika_is_site_admin() && (int) get_post_field( 'post_author', $pid ) !== $uid ) : ?><span class="atk-dot"></span><span>نشرته: <?php echo esc_html( get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $pid ) ) ); ?></span><?php endif; ?>
							<span class="atk-dot"></span>
							<time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
							<?php if ( $draft ) : ?><span class="atk-pill">مسودة</span><?php endif; ?>
						</div>
					</div>
					<div class="atk-item-actions">
						<?php if ( ! $draft ) : ?><a class="atk-icon-btn" href="<?php the_permalink(); ?>" target="_blank" rel="noopener" title="عرض" aria-label="عرض"><?php echo atika_icon( 'eye' ); // phpcs:ignore ?></a><?php endif; ?>
						<a class="atk-icon-btn" href="<?php echo esc_url( atika_dash_url( array( 'view' => 'form', 'id' => $pid ) ) ); ?>" title="تعديل" aria-label="تعديل"><?php echo atika_icon( 'edit' ); // phpcs:ignore ?></a>
						<form method="post" data-confirm="حذف «<?php echo esc_attr( get_the_title() ); ?>» وكل صوره نهائياً؟">
							<?php wp_nonce_field( 'atika_delete_' . $pid, '_atika_nonce' ); ?>
							<input type="hidden" name="atika_dash" value="delete"><input type="hidden" name="post_id" value="<?php echo esc_attr( $pid ); ?>">
							<button class="atk-icon-btn atk-danger" type="submit" title="حذف" aria-label="حذف"><?php echo atika_icon( 'trash' ); // phpcs:ignore ?></button>
						</form>
					</div>
				</article>
			<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php if ( $list->max_num_pages > 1 ) : ?>
			<nav class="atk-pager">
				<?php for ( $i = 1; $i <= $list->max_num_pages; $i++ ) : ?>
					<a class="<?php echo $i === $page ? 'on' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'pg' => $i, 'q' => $q, 'sec' => $sec ?: null, 'st' => $st ?: null ), atika_dash_url() ) ); ?>"><?php echo esc_html( atika_ar_num( $i ) ); ?></a>
				<?php endfor; ?>
			</nav>
		<?php endif; ?>
	<?php endif;
}

/* ---------------- View: add / edit form ---------------- */

function atika_view_form( $uid ) {
	$id   = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : ( isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0 );
	$post = $id ? atika_own_post( $id ) : null;
	if ( $id && ! $post ) {
		echo atika_notice( 'هذا الإنجاز غير موجود أو لا تملكين صلاحية تعديله.' ); // phpcs:ignore
		return;
	}
	$old = $GLOBALS['atika_form_old'];
	$e   = $GLOBALS['atika_form_errors'];
	$val = function ( $k, $fallback ) use ( $old ) {
		return isset( $old[ $k ] ) ? $old[ $k ] : $fallback;
	};
	$secs     = $post ? wp_get_post_terms( $post->ID, ATIKA_TAX_SECTION, array( 'fields' => 'ids' ) ) : array();
	$title    = $val( 'title', $post ? $post->post_title : '' );
	$teacher  = $val( 'teacher', $post ? get_post_meta( $post->ID, 'atika_teacher', true ) : '' );
	$section  = (int) $val( 'section', $secs ? $secs[0] : ( isset( $_GET['sec'] ) ? absint( $_GET['sec'] ) : 0 ) );
	$date     = $val( 'date', $post ? get_the_date( 'Y-m-d', $post ) : current_time( 'Y-m-d' ) );
	$desc     = $val( 'desc', $post ? $post->post_content : '' );
	$status   = $val( 'status', $post ? $post->post_status : 'publish' );
	$images   = $post ? atika_gallery_ids( $post->ID ) : array();
	$cover    = $post ? (int) get_post_thumbnail_id( $post->ID ) : 0;
	$teachers = atika_head_teachers( $uid );
	$subj_cur = '';
	if ( $post ) {
		$st = get_the_terms( $post->ID, ATIKA_TAX_SUBJECT );
		$subj_cur = $st && ! is_wp_error( $st ) ? $st[0]->name : '';
	}
	$subject_val = $val( 'subject_in', $subj_cur );
	$f        = function ( $k ) use ( $e ) {
		return isset( $e[ $k ] ) ? ' aria-invalid="true" aria-describedby="err-' . esc_attr( $k ) . '"' : '';
	};
	?>
	<div class="atk-panel">
		<div class="atk-panel-head">
			<h2><?php echo $post ? 'تعديل الإنجاز' : 'إضافة إنجاز جديد'; ?></h2>
			<a href="<?php echo esc_url( atika_dash_url() ); ?>" class="atk-link">رجوع إلى القائمة</a>
		</div>
		<?php
		if ( isset( $e['form'] ) ) {
			echo atika_notice( esc_html( $e['form'] ) ); // phpcs:ignore
		} elseif ( $e ) {
			echo atika_notice( 'راجعي الحقول المظللة بالأحمر.' . ( ! empty( $GLOBALS['atika_files_lost'] ) ? ' أعيدي اختيار الصور الجديدة لأن المتصفح لا يحتفظ بها بعد الإرسال.' : '' ) ); // phpcs:ignore
		}
		?>
		<form method="post" enctype="multipart/form-data" class="atk-form atk-ach-form" id="atk-ach-form">
			<?php wp_nonce_field( 'atika_save', '_atika_nonce' ); ?>
			<input type="hidden" name="atika_dash" value="save">
			<input type="hidden" name="post_id" value="<?php echo esc_attr( $post ? $post->ID : 0 ); ?>">

			<div class="atk-grid2">
				<div class="atk-col">
					<label class="atk-field"><span>عنوان الإنجاز</span>
						<input type="text" name="title" id="atk-title" maxlength="140" value="<?php echo esc_attr( $title ); ?>" required placeholder="مثال: مسابقة الإلقاء الشعري للصف السابع"<?php echo $f( 'title' ); // phpcs:ignore ?>>
						<?php echo atika_field_error( 'title' ); // phpcs:ignore ?></label>

					<?php if ( ! atika_is_head() ) : ?>
						<label class="atk-field"><span>المادة</span>
							<input type="text" name="subject" id="atk-subject-in" list="atk-subject-list" maxlength="60" value="<?php echo esc_attr( $subject_val ); ?>" required autocomplete="off" placeholder="مثال: اللغة العربية"<?php echo $f( 'subject' ); // phpcs:ignore ?>>
							<datalist id="atk-subject-list"><?php foreach ( atika_subject_names() as $sn ) : ?><option value="<?php echo esc_attr( $sn ); ?>"></option><?php endforeach; ?></datalist>
							<small class="atk-hint">اختاري مادة موجودة أو اكتبي مادة جديدة.</small>
							<?php echo atika_field_error( 'subject' ); // phpcs:ignore ?></label>
					<?php endif; ?>

					<div class="atk-row">
						<label class="atk-field"><span>المعلمة صاحبة الإنجاز</span>
							<input type="text" name="teacher" id="atk-teacher" list="atk-teacher-list" maxlength="80" value="<?php echo esc_attr( $teacher ); ?>" required autocomplete="off" placeholder="اكتبي أو اختاري من القائمة"<?php echo $f( 'teacher' ); // phpcs:ignore ?>>
							<datalist id="atk-teacher-list"><?php foreach ( $teachers as $t ) : ?><option value="<?php echo esc_attr( $t ); ?>"></option><?php endforeach; ?></datalist>
							<?php echo atika_field_error( 'teacher' ); // phpcs:ignore ?></label>
						<label class="atk-field"><span>تاريخ الإنجاز</span>
							<input type="date" name="date" id="atk-date" value="<?php echo esc_attr( $date ); ?>" max="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"<?php echo $f( 'date' ); // phpcs:ignore ?>>
							<?php echo atika_field_error( 'date' ); // phpcs:ignore ?></label>
					</div>

					<fieldset class="atk-field atk-sections"<?php echo $f( 'section' ); // phpcs:ignore ?>>
						<legend>المحور</legend>
						<div class="atk-sec-opts">
							<?php foreach ( atika_get_sections() as $s ) : ?>
								<label style="--c:<?php echo esc_attr( atika_section_color( $s ) ); ?>"><input type="radio" name="section" id="atk-sec-<?php echo esc_attr( $s->term_id ); ?>" value="<?php echo esc_attr( $s->term_id ); ?>" <?php checked( $section, $s->term_id ); ?> required><span><?php echo esc_html( $s->name ); ?></span></label>
							<?php endforeach; ?>
						</div>
						<?php echo atika_field_error( 'section' ); // phpcs:ignore ?>
					</fieldset>

					<label class="atk-field"><span>وصف الإنجاز</span>
						<textarea name="description" id="atk-desc" rows="7" required placeholder="الهدف من النشاط، الفئة المستهدفة، ما تم تنفيذه، والنتائج"<?php echo $f( 'description' ); // phpcs:ignore ?>><?php echo esc_textarea( $desc ); ?></textarea>
						<?php echo atika_field_error( 'description' ); // phpcs:ignore ?></label>
				</div>

				<div class="atk-col">
					<div class="atk-field">
						<span>الصور</span>
						<?php if ( $images ) : ?>
							<div class="atk-existing">
								<?php foreach ( $images as $aid ) : ?>
									<div class="atk-ex">
										<?php echo wp_get_attachment_image( $aid, 'thumbnail', false, array( 'alt' => '' ) ); // phpcs:ignore ?>
										<label class="atk-ex-cover" title="صورة الغلاف"><input type="radio" name="cover" id="atk-cover-<?php echo esc_attr( $aid ); ?>" value="<?php echo esc_attr( $aid ); ?>" <?php checked( $cover, $aid ); ?>><span>غلاف</span></label>
										<label class="atk-ex-rm" title="حذف الصورة"><input type="checkbox" name="remove_images[]" id="atk-rm-<?php echo esc_attr( $aid ); ?>" value="<?php echo esc_attr( $aid ); ?>"><span>حذف</span></label>
									</div>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
						<label class="atk-drop" id="atk-drop"<?php echo $f( 'images' ); // phpcs:ignore ?>>
							<?php echo atika_icon( 'image' ); // phpcs:ignore ?>
							<strong>اسحبي الصور هنا أو اضغطي للاختيار</strong>
							<small>حتى <?php echo esc_html( atika_ar_num( (int) atika_setting( 'max_images' ) ) ); ?> صور، كل صورة حتى <?php echo esc_html( atika_ar_num( (int) atika_setting( 'max_image_mb' ) ) ); ?> ميغابايت (JPG، PNG، WEBP)</small>
							<input type="file" name="images[]" id="atk-images" accept="image/jpeg,image/png,image/webp,image/gif,image/heic" multiple data-existing="<?php echo esc_attr( count( $images ) ); ?>">
						</label>
						<div class="atk-previews" id="atk-previews" aria-live="polite"></div>
						<?php echo atika_field_error( 'images' ); // phpcs:ignore ?>
					</div>

					<fieldset class="atk-field atk-status">
						<legend>الحالة</legend>
						<label><input type="radio" name="status" id="atk-st-pub" value="publish" <?php checked( $status, 'publish' ); ?>><span><strong>نشر على الموقع</strong><small>يظهر للزوار فوراً</small></span></label>
						<label><input type="radio" name="status" id="atk-st-draft" value="draft" <?php checked( $status, 'draft' ); ?>><span><strong>مسودة</strong><small>محفوظ عندك فقط</small></span></label>
					</fieldset>

					<?php if ( atika_is_head() ) : ?>
						<div class="atk-subject-box">يُنشر ضمن مادة: <strong><?php echo esc_html( atika_head_subject_name( $uid ) ); ?></strong></div>
					<?php endif; ?>
				</div>
			</div>

			<div class="atk-form-foot">
				<a href="<?php echo esc_url( atika_dash_url() ); ?>" class="atk-btn atk-btn-ghost">إلغاء</a>
				<button type="submit" class="atk-btn atk-btn-green" id="atk-save"><?php echo $post ? 'حفظ التعديلات' : 'حفظ الإنجاز'; ?></button>
			</div>
		</form>
	</div>
	<?php
}

/* ---------------- View: teachers ---------------- */

function atika_view_teachers( $uid ) {
	$list   = atika_head_teachers( $uid );
	$counts = array();
	$posts  = get_posts( array( 'post_type' => ATIKA_CPT, 'author' => $uid, 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids' ) );
	foreach ( $posts as $pid ) {
		$t = get_post_meta( $pid, 'atika_teacher', true );
		if ( $t ) {
			$counts[ $t ] = isset( $counts[ $t ] ) ? $counts[ $t ] + 1 : 1;
		}
	}
	?>
	<div class="atk-panel">
		<div class="atk-panel-head"><h2>معلمات القسم</h2><span class="atk-muted"><?php echo esc_html( atika_ar_num( count( $list ) ) ); ?> معلمة</span></div>
		<p class="atk-muted">أسماء معلمات قسمك تظهر كاقتراحات عند إضافة إنجاز، فلا تحتاجين لكتابتها كل مرة. أي اسم جديد تكتبينه في إنجاز يُضاف هنا تلقائياً.</p>
		<form method="post" class="atk-form atk-inline">
			<?php wp_nonce_field( 'atika_teachers', '_atika_nonce' ); ?>
			<input type="hidden" name="atika_dash" value="teacher_add">
			<input type="text" name="teacher" id="atk-new-teacher" placeholder="اسم المعلمة الكامل" required maxlength="80" aria-label="اسم المعلمة">
			<button type="submit" class="atk-btn atk-btn-primary"><?php echo atika_icon( 'plus' ); // phpcs:ignore ?>إضافة</button>
		</form>
		<?php if ( $list ) : ?>
			<ul class="atk-teachers">
				<?php foreach ( $list as $t ) : ?>
					<li>
						<span class="atk-avatar atk-avatar-sm"><?php echo esc_html( mb_substr( $t, 0, 1 ) ); ?></span>
						<span class="atk-t-name"><?php echo esc_html( $t ); ?></span>
						<span class="atk-muted"><?php echo esc_html( atika_ar_num( isset( $counts[ $t ] ) ? $counts[ $t ] : 0 ) ); ?> إنجاز</span>
						<form method="post" data-confirm="إزالة <?php echo esc_attr( $t ); ?> من القائمة؟">
							<?php wp_nonce_field( 'atika_teachers', '_atika_nonce' ); ?>
							<input type="hidden" name="atika_dash" value="teacher_remove"><input type="hidden" name="teacher" value="<?php echo esc_attr( $t ); ?>">
							<button class="atk-icon-btn atk-danger" type="submit" aria-label="إزالة <?php echo esc_attr( $t ); ?>"><?php echo atika_icon( 'trash' ); // phpcs:ignore ?></button>
						</form>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<div class="atk-empty"><?php echo atika_icon( 'users' ); // phpcs:ignore ?><p>لم تُضيفي معلمات بعد.</p></div>
		<?php endif; ?>
	</div>
	<?php
}

/* ---------------- View: profile ---------------- */

function atika_view_profile( $user ) {
	$e   = $GLOBALS['atika_form_errors'];
	$old = $GLOBALS['atika_form_old'];
	$f   = function ( $k ) use ( $e ) {
		return isset( $e[ $k ] ) ? ' aria-invalid="true" aria-describedby="err-' . esc_attr( $k ) . '"' : '';
	};
	$subject = isset( $_POST['subject'] ) ? atika_clean_subject( $_POST['subject'] ) : atika_head_subject_name( $user->ID );
	?>
	<div class="atk-grid2">
		<div class="atk-panel">
			<div class="atk-panel-head"><h2>بيانات الحساب</h2></div>
			<form method="post" class="atk-form">
				<?php wp_nonce_field( 'atika_profile', '_atika_nonce' ); ?>
				<input type="hidden" name="atika_dash" value="profile">
				<label class="atk-field"><span>الاسم الكامل</span>
					<input type="text" name="full_name" id="atk-p-name" value="<?php echo esc_attr( isset( $_POST['full_name'] ) ? sanitize_text_field( wp_unslash( $_POST['full_name'] ) ) : $user->display_name ); ?>" required<?php echo $f( 'full_name' ); // phpcs:ignore ?>>
					<?php echo atika_field_error( 'full_name' ); // phpcs:ignore ?></label>
				<?php if ( atika_is_head() ) : ?>
				<label class="atk-field"><span>اسم المادة</span>
					<input type="text" name="subject" id="atk-p-subject" value="<?php echo esc_attr( $subject ); ?>" required maxlength="60"<?php echo $f( 'subject' ); // phpcs:ignore ?>>
					<small class="atk-hint">تغيير الاسم يُحدّث صفحة المادة وكل إنجازاتها.</small>
					<?php echo atika_field_error( 'subject' ); // phpcs:ignore ?></label>
				<label class="atk-field"><span>البريد الإلكتروني</span>
					<input type="email" id="atk-p-email" value="<?php echo esc_attr( $user->user_email ); ?>" dir="ltr" disabled>
					<small class="atk-hint">لتغيير البريد تواصلي مع إدارة الموقع.</small></label>
				<?php else : ?>
				<label class="atk-field"><span>اسم المستخدم</span>
					<input type="text" id="atk-p-login" value="<?php echo esc_attr( $user->user_login ); ?>" dir="ltr" disabled></label>
				<label class="atk-field"><span>البريد الإلكتروني</span>
					<input type="email" name="email" id="atk-p-email" value="<?php echo esc_attr( isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : $user->user_email ); ?>" dir="ltr" autocomplete="email"<?php echo $f( 'email' ); // phpcs:ignore ?>>
					<small class="atk-hint">أضيفي بريدك ليمكنك استعادة كلمة المرور إذا نسيتِها.</small>
					<?php echo atika_field_error( 'email' ); // phpcs:ignore ?></label>
				<?php endif; ?>
				<label class="atk-field"><span>رقم الجوال</span>
					<input type="tel" name="phone" id="atk-p-phone" dir="ltr" value="<?php echo esc_attr( get_user_meta( $user->ID, 'atika_phone', true ) ); ?>"></label>
				<button class="atk-btn atk-btn-primary" type="submit">حفظ البيانات</button>
			</form>
		</div>
		<div class="atk-panel">
			<div class="atk-panel-head"><h2>تغيير كلمة المرور</h2></div>
			<form method="post" class="atk-form">
				<?php wp_nonce_field( 'atika_password', '_atika_nonce' ); ?>
				<input type="hidden" name="atika_dash" value="password">
				<label class="atk-field"><span>كلمة المرور الحالية</span>
					<input type="password" name="current" id="atk-pw-cur" required autocomplete="current-password"<?php echo $f( 'current' ); // phpcs:ignore ?>>
					<?php echo atika_field_error( 'current' ); // phpcs:ignore ?></label>
				<label class="atk-field"><span>كلمة المرور الجديدة</span>
					<input type="password" name="new" id="atk-pw-new" required minlength="8" autocomplete="new-password" data-strength<?php echo $f( 'new' ); // phpcs:ignore ?>>
					<?php echo atika_field_error( 'new' ); // phpcs:ignore ?></label>
				<label class="atk-field"><span>تأكيد كلمة المرور الجديدة</span>
					<input type="password" name="new2" id="atk-pw-new2" required autocomplete="new-password"<?php echo $f( 'new2' ); // phpcs:ignore ?>>
					<?php echo atika_field_error( 'new2' ); // phpcs:ignore ?></label>
				<button class="atk-btn atk-btn-ghost" type="submit">تغيير كلمة المرور</button>
			</form>
		</div>
	</div>
	<?php
}
