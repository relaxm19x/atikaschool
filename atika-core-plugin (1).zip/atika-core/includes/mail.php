<?php
defined( 'ABSPATH' ) || exit;

/**
 * Build a branded RTL HTML email body.
 *
 * @param string $heading Big heading inside the email.
 * @param string $body    HTML paragraphs (already escaped).
 * @param array  $button  Optional array( 'label' => .., 'url' => .. ).
 */
function atika_mail_html( $heading, $body, $button = array() ) {
	$site  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$logo  = esc_url( atika_logo_url() );
	$btn   = '';
	$plain = '';
	if ( ! empty( $button['url'] ) ) {
		$url   = esc_url( $button['url'] );
		$btn   = '<table role="presentation" cellspacing="0" cellpadding="0" style="margin:26px auto 8px"><tr><td style="background:#037b3e;border-radius:8px">'
			. '<a href="' . $url . '" style="display:inline-block;padding:13px 30px;color:#ffffff;text-decoration:none;font-weight:bold;font-size:16px;font-family:Tahoma,Arial,sans-serif">' . esc_html( $button['label'] ) . '</a></td></tr></table>';
		$plain = '<p style="font-size:12px;color:#7a7f91;margin-top:18px;word-break:break-all">إذا لم يعمل الزر، انسخي هذا الرابط في المتصفح:<br><a href="' . $url . '" style="color:#1b2242">' . $url . '</a></p>';
	}
	return '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>'
		. '<body style="margin:0;background:#f3f4f8;font-family:Tahoma,Arial,sans-serif;direction:rtl">'
		. '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f4f8;padding:28px 12px"><tr><td align="center">'
		. '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden">'
		. '<tr><td style="height:6px;background:linear-gradient(90deg,#037b3e 0 33%,#1b2242 33% 66%,#7a2934 66%);background-color:#1b2242"></td></tr>'
		. '<tr><td align="center" style="padding:26px 24px 6px"><img src="' . $logo . '" alt="' . esc_attr( $site ) . '" width="240" style="max-width:240px;height:auto"></td></tr>'
		. '<tr><td style="padding:10px 32px 30px;text-align:right;color:#141a33;font-size:15px;line-height:1.9">'
		. '<h1 style="font-size:21px;color:#1b2242;margin:12px 0 10px">' . esc_html( $heading ) . '</h1>'
		. $body . $btn . $plain
		. '</td></tr>'
		. '<tr><td style="background:#f6f7fa;padding:16px 24px;text-align:center;color:#7a7f91;font-size:12px">' . esc_html( $site ) . '<br>رسالة آلية، يرجى عدم الرد عليها.</td></tr>'
		. '</table></td></tr></table></body></html>';
}

/** Send a branded RTL HTML email. */
function atika_mail( $to, $subject, $heading, $body, $button = array() ) {
	return wp_mail( $to, $subject, atika_mail_html( $heading, $body, $button ), array( 'Content-Type: text/html; charset=UTF-8' ) );
}

/* Friendly sender name for every email the site sends. */
add_filter( 'wp_mail_from_name', function ( $name ) {
	return 'WordPress' === $name ? wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) : $name;
} );

/* Password reset email for heads: branded, and the link opens our own reset page. */
add_filter( 'retrieve_password_notification_email', function ( $email, $key, $user_login, $user ) {
	if ( ! atika_is_head( $user ) && ! atika_is_team( $user ) ) {
		return $email;
	}
	$url  = atika_page_url( 'login', array( 'action' => 'rp', 'key' => $key, 'login' => rawurlencode( $user_login ) ) );
	$body = '<p>مرحباً ' . esc_html( $user->display_name ) . '،</p>'
		. '<p>وصلنا طلب لإعادة تعيين كلمة المرور لحسابك. اضغطي الزر أدناه لاختيار كلمة مرور جديدة. الرابط صالح لمدة ٢٤ ساعة ويُستخدم مرة واحدة.</p>'
		. '<p style="color:#7a7f91;font-size:13px">إذا لم تطلبي ذلك فتجاهلي هذه الرسالة، وستبقى كلمة مرورك كما هي.</p>';
	$email['subject'] = 'إعادة تعيين كلمة المرور | ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$email['message'] = atika_mail_html( 'إعادة تعيين كلمة المرور', $body, array( 'label' => 'تعيين كلمة مرور جديدة', 'url' => $url ) );
	$email['headers'] = array( 'Content-Type: text/html; charset=UTF-8' );
	return $email;
}, 10, 4 );

/* Tell the head when her password changes (security notice, like major sites). */
add_filter( 'password_change_email', function ( $email, $user ) {
	$u = get_userdata( $user['ID'] );
	if ( ! $u || ( ! atika_is_head( $u ) && ! atika_is_team( $u ) ) ) {
		return $email;
	}
	$body = '<p>مرحباً ' . esc_html( $u->display_name ) . '،</p><p>تم تغيير كلمة المرور لحسابك بنجاح.</p><p style="color:#7a7f91;font-size:13px">إذا لم تقومي بهذا التغيير، أعيدي تعيين كلمة المرور فوراً وتواصلي مع إدارة الموقع.</p>';
	$email['subject'] = 'تم تغيير كلمة المرور | ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$email['message'] = atika_mail_html( 'تم تغيير كلمة المرور', $body, array( 'label' => 'إعادة تعيين كلمة المرور', 'url' => atika_page_url( 'login', array( 'action' => 'lost' ) ) ) );
	$email['headers'] = array( 'Content-Type: text/html; charset=UTF-8' );
	return $email;
}, 10, 2 );
