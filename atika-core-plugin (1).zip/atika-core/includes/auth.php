<?php
defined( 'ABSPATH' ) || exit;

$GLOBALS['atika_form_errors'] = array();
$GLOBALS['atika_form_old']    = array();

/* ======================================================================
 * Assets for system pages
 * ==================================================================== */

add_action( 'wp_enqueue_scripts', function () {
	if ( ! atika_is_system_page() ) {
		return;
	}
	wp_enqueue_style( 'atika-front', ATIKA_URL . 'assets/css/front.css', array(), ATIKA_VERSION );
	wp_enqueue_script( 'atika-front', ATIKA_URL . 'assets/js/front.js', array(), ATIKA_VERSION, true );
	wp_localize_script( 'atika-front', 'ATIKA', array(
		'maxImages' => (int) atika_setting( 'max_images' ),
		'maxMb'     => (int) atika_setting( 'max_image_mb' ),
	) );
} );

/* ======================================================================
 * Form handling (runs before output so we can redirect)
 * ==================================================================== */

add_action( 'template_redirect', 'atika_handle_auth_requests', 5 );
function atika_handle_auth_requests() {
	// Email verification link.
	if ( isset( $_GET['atika_verify'], $_GET['uid'] ) ) {
		atika_handle_verify( sanitize_text_field( wp_unslash( $_GET['atika_verify'] ) ), absint( $_GET['uid'] ) );
		return;
	}

	if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) || empty( $_POST['atika_action'] ) ) {
		return;
	}
	$action = sanitize_key( wp_unslash( $_POST['atika_action'] ) );
	if ( 'register' === $action ) {
		atika_handle_register();
	} elseif ( 'login' === $action ) {
		atika_handle_login();
	} elseif ( 'resend' === $action ) {
		atika_handle_resend();
	} elseif ( 'lost' === $action ) {
		atika_handle_lost();
	} elseif ( 'resetpass' === $action ) {
		atika_handle_resetpass();
	}
}

function atika_err( $field, $msg ) {
	$GLOBALS['atika_form_errors'][ $field ] = $msg;
}

function atika_old( $field ) {
	return isset( $GLOBALS['atika_form_old'][ $field ] ) ? $GLOBALS['atika_form_old'][ $field ] : '';
}

/* ---------------- Register ---------------- */

function atika_handle_register() {
	if ( ! atika_registration_open() ) {
		wp_safe_redirect( atika_page_url( 'register' ) );
		exit;
	}
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_register' ) ) {
		atika_err( 'form', 'انتهت صلاحية الصفحة. حدّثي الصفحة ثم أعيدي المحاولة.' );
		return;
	}
	// Honeypot: real people never fill this hidden field.
	if ( ! empty( $_POST['website'] ) ) {
		wp_safe_redirect( atika_page_url( 'register', array( 'registered' => 1 ) ) );
		exit;
	}

	$name    = sanitize_text_field( wp_unslash( isset( $_POST['full_name'] ) ? $_POST['full_name'] : '' ) );
	$email   = sanitize_email( wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : '' ) );
	$phone   = preg_replace( '/[^0-9+ ]/', '', sanitize_text_field( wp_unslash( isset( $_POST['phone'] ) ? $_POST['phone'] : '' ) ) );
	$subject = atika_clean_subject( isset( $_POST['subject'] ) ? $_POST['subject'] : '' );
	$pass    = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : ''; // phpcs:ignore -- passwords are not sanitized.
	$pass2   = isset( $_POST['password2'] ) ? (string) wp_unslash( $_POST['password2'] ) : ''; // phpcs:ignore

	$GLOBALS['atika_form_old'] = compact( 'name', 'email', 'phone', 'subject' );

	if ( mb_strlen( $name ) < 5 || false === strpos( $name, ' ' ) ) {
		atika_err( 'full_name', 'اكتبي الاسم الثنائي على الأقل.' );
	}
	if ( ! is_email( $email ) ) {
		atika_err( 'email', 'البريد الإلكتروني غير صحيح.' );
	} elseif ( email_exists( $email ) ) {
		atika_err( 'email', 'هذا البريد مسجّل مسبقاً. سجّلي الدخول بدلاً من ذلك، أو استعيدي كلمة المرور.' );
	}
	if ( mb_strlen( $subject ) < 2 || mb_strlen( $subject ) > 60 ) {
		atika_err( 'subject', 'اكتبي اسم المادة التي ترأسين قسمها.' );
	} elseif ( atika_subject_taken_by( $subject ) ) {
		atika_err( 'subject', 'هذه المادة مسجّلة باسم رئيسة قسم أخرى. إذا كان هناك خطأ تواصلي مع إدارة المدرسة.' );
	}
	$digits = preg_replace( '/\D/', '', $phone );
	if ( 0 === strpos( $digits, '00965' ) ) {
		$digits = substr( $digits, 5 );
	} elseif ( 0 === strpos( $digits, '965' ) && strlen( $digits ) === 11 ) {
		$digits = substr( $digits, 3 );
	}
	if ( ! preg_match( '/^[124569]\d{7}$/', $digits ) ) {
		atika_err( 'phone', 'اكتبي رقم جوال كويتي صحيح من ٨ أرقام.' );
	} else {
		$phone = $digits;
	}
	$prob = atika_password_problem( $pass, array( strstr( $email, '@', true ) ) );
	if ( $prob ) {
		atika_err( 'password', $prob );
	} elseif ( $pass !== $pass2 ) {
		atika_err( 'password2', 'كلمتا المرور غير متطابقتين.' );
	}
	if ( empty( $_POST['consent'] ) ) {
		atika_err( 'consent', 'يجب الموافقة على سياسة الخصوصية لإنشاء الحساب.' );
	}
	if ( $GLOBALS['atika_form_errors'] ) {
		return;
	}
	if ( ! atika_rate_ok( 'register', 5, HOUR_IN_SECONDS ) ) {
		atika_err( 'form', 'تم إرسال طلبات كثيرة من هذا الجهاز. حاولي مرة أخرى بعد ساعة.' );
		return;
	}

	$login = sanitize_user( strtolower( strstr( $email, '@', true ) ), true );
	$login = $login ? $login : 'head';
	$base  = $login;
	$i     = 2;
	while ( username_exists( $login ) ) {
		$login = $base . $i++;
	}

	$parts   = explode( ' ', $name, 2 );
	$user_id = wp_insert_user( array(
		'user_login'   => $login,
		'user_email'   => $email,
		'user_pass'    => $pass,
		'display_name' => $name,
		'first_name'   => $parts[0],
		'last_name'    => isset( $parts[1] ) ? $parts[1] : '',
		'role'         => ATIKA_ROLE,
		'show_admin_bar_front' => 'false',
	) );
	if ( is_wp_error( $user_id ) ) {
		atika_err( 'form', 'تعذّر إنشاء الحساب: ' . esc_html( $user_id->get_error_message() ) );
		return;
	}

	update_user_meta( $user_id, 'atika_status', ATIKA_STATUS_UNVERIFIED );
	update_user_meta( $user_id, 'atika_subject_name', $subject );
	update_user_meta( $user_id, 'atika_phone', $phone );
	update_user_meta( $user_id, 'atika_consent', current_time( 'mysql' ) );

	atika_send_verification( $user_id );

	wp_safe_redirect( atika_page_url( 'register', array( 'registered' => 1, 'to' => rawurlencode( $email ) ) ) );
	exit;
}

function atika_send_verification( $user_id ) {
	$user  = get_userdata( $user_id );
	$raw   = wp_generate_password( 40, false, false );
	update_user_meta( $user_id, 'atika_verify_hash', hash_hmac( 'sha256', $raw, wp_salt( 'auth' ) ) );
	update_user_meta( $user_id, 'atika_verify_expires', time() + (int) atika_setting( 'token_hours' ) * HOUR_IN_SECONDS );

	$url  = add_query_arg( array( 'atika_verify' => $raw, 'uid' => $user_id ), home_url( '/' ) );
	$body = '<p>مرحباً ' . esc_html( $user->display_name ) . '،</p>'
		. '<p>شكراً لتسجيلك رئيسةً لقسم <strong>' . esc_html( get_user_meta( $user_id, 'atika_subject_name', true ) ) . '</strong> في منصة إنجازات المدرسة.</p>'
		. '<p>اضغطي الزر أدناه لتوثيق بريدك الإلكتروني. الرابط صالح لمدة ' . esc_html( atika_ar_num( (int) atika_setting( 'token_hours' ) ) ) . ' ساعة.</p>';
	return atika_mail( $user->user_email, 'توثيق بريدك الإلكتروني | ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'توثيق البريد الإلكتروني', $body, array( 'label' => 'توثيق البريد', 'url' => $url ) );
}

/* ---------------- Verify ---------------- */

function atika_handle_verify( $raw, $user_id ) {
	$user = get_userdata( $user_id );
	if ( ! $user || ! atika_is_head( $user ) ) {
		wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'invalid' ) ) );
		exit;
	}
	if ( ATIKA_STATUS_UNVERIFIED !== atika_head_status( $user_id ) ) {
		wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'already' ) ) );
		exit;
	}
	$hash    = (string) get_user_meta( $user_id, 'atika_verify_hash', true );
	$expires = (int) get_user_meta( $user_id, 'atika_verify_expires', true );
	if ( ! $hash || ! hash_equals( $hash, hash_hmac( 'sha256', $raw, wp_salt( 'auth' ) ) ) ) {
		wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'invalid' ) ) );
		exit;
	}
	if ( $expires < time() ) {
		wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'expired' ) ) );
		exit;
	}

	delete_user_meta( $user_id, 'atika_verify_hash' );
	delete_user_meta( $user_id, 'atika_verify_expires' );
	update_user_meta( $user_id, 'atika_email_verified', current_time( 'mysql' ) );

	if ( atika_setting( 'require_approval' ) ) {
		update_user_meta( $user_id, 'atika_status', ATIKA_STATUS_PENDING );
		atika_notify_admin_pending( $user_id );
		wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'pending' ) ) );
	} else {
		atika_activate_head( $user_id, false );
		wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'ok' ) ) );
	}
	exit;
}

function atika_notify_admin_pending( $user_id ) {
	$to = atika_setting( 'notify_email' );
	if ( ! is_email( $to ) ) {
		return;
	}
	$u    = get_userdata( $user_id );
	$body = '<p>وثّقت رئيسة قسم جديدة بريدها وتنتظر الاعتماد:</p>'
		. '<p><strong>الاسم:</strong> ' . esc_html( $u->display_name ) . '<br><strong>المادة:</strong> ' . esc_html( get_user_meta( $user_id, 'atika_subject_name', true ) ) . '<br><strong>البريد:</strong> ' . esc_html( $u->user_email ) . '</p>';
	atika_mail( $to, 'طلب اعتماد رئيسة قسم: ' . $u->display_name, 'طلب اعتماد جديد', $body, array( 'label' => 'مراجعة الطلب', 'url' => admin_url( 'admin.php?page=atika-heads&status=pending' ) ) );
}

/** Activate a head: give her the subject and (optionally) email her. */
function atika_activate_head( $user_id, $notify = true ) {
	update_user_meta( $user_id, 'atika_status', ATIKA_STATUS_ACTIVE );
	atika_assign_subject( $user_id );
	if ( $notify ) {
		$u    = get_userdata( $user_id );
		$body = '<p>مرحباً ' . esc_html( $u->display_name ) . '،</p><p>تم اعتماد حسابك رئيسةً لقسم <strong>' . esc_html( atika_head_subject_name( $user_id ) ) . '</strong>. يمكنك الآن الدخول ونشر إنجازات معلمات قسمك.</p>';
		atika_mail( $u->user_email, 'تم اعتماد حسابك | ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'تم اعتماد حسابك', $body, array( 'label' => 'الدخول إلى لوحة التحكم', 'url' => atika_page_url( 'login' ) ) );
	}
}

/* ---------------- Resend ---------------- */

function atika_handle_resend() {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_resend' ) ) {
		atika_err( 'resend', 'انتهت صلاحية الصفحة. حدّثيها وأعيدي المحاولة.' );
		return;
	}
	$email = sanitize_email( wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : '' ) );
	if ( ! atika_rate_ok( 'resend', 4, HOUR_IN_SECONDS ) ) {
		atika_err( 'resend', 'طلبات كثيرة. حاولي بعد ساعة.' );
		return;
	}
	$user = $email ? get_user_by( 'email', $email ) : false;
	if ( $user && atika_is_head( $user ) && ATIKA_STATUS_UNVERIFIED === atika_head_status( $user->ID ) ) {
		atika_send_verification( $user->ID );
	}
	// Same answer whether or not the address exists.
	wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'resent' ) ) );
	exit;
}

/* ---------------- Lost / reset password ---------------- */

/** Shared password rule used by registration, reset and profile. Returns an error message or ''. */
function atika_password_problem( $pass, $user_inputs = array() ) {
	if ( strlen( $pass ) < 8 ) {
		return 'كلمة المرور يجب أن تكون ٨ أحرف على الأقل.';
	}
	if ( ! preg_match( '/[0-9]/', $pass ) || ! preg_match( '/[^0-9]/', $pass ) ) {
		return 'استخدمي أحرفاً وأرقاماً معاً في كلمة المرور.';
	}
	foreach ( $user_inputs as $v ) {
		$v = strtolower( (string) $v );
		if ( strlen( $v ) >= 4 && false !== strpos( strtolower( $pass ), $v ) ) {
			return 'لا تستخدمي بريدك أو اسمك داخل كلمة المرور.';
		}
	}
	$common = array( '12345678', '123456789', 'password1', 'qwerty123', 'abc12345', '11111111', 'password', 'a1234567', '1234567a' );
	if ( in_array( strtolower( $pass ), $common, true ) ) {
		return 'كلمة المرور هذه شائعة وسهلة التخمين. اختاري كلمة أقوى.';
	}
	return '';
}

function atika_handle_lost() {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_lost' ) ) {
		atika_err( 'lost', 'انتهت صلاحية الصفحة. حدّثيها وأعيدي المحاولة.' );
		return;
	}
	$email = sanitize_email( wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : '' ) );
	$GLOBALS['atika_form_old'] = array( 'email' => $email );
	if ( ! is_email( $email ) ) {
		atika_err( 'lost', 'اكتبي بريداً إلكترونياً صحيحاً.' );
		return;
	}
	if ( ! atika_rate_ok( 'lost', 5, HOUR_IN_SECONDS ) ) {
		atika_err( 'lost', 'طلبات كثيرة من هذا الجهاز. حاولي بعد ساعة.' );
		return;
	}
	$user = get_user_by( 'email', $email );
	if ( $user && ( ! atika_is_head( $user ) || ATIKA_STATUS_SUSPENDED !== atika_head_status( $user->ID ) ) ) {
		retrieve_password( $user->user_login );
	}
	// Same answer whether or not the address exists, so the form cannot be used to discover accounts.
	wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'reset_sent' ) ) );
	exit;
}

function atika_handle_resetpass() {
	$key   = isset( $_POST['rp_key'] ) ? sanitize_text_field( wp_unslash( $_POST['rp_key'] ) ) : '';
	$login = isset( $_POST['rp_login'] ) ? sanitize_user( wp_unslash( $_POST['rp_login'] ) ) : '';
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_resetpass' ) ) {
		atika_err( 'form', 'انتهت صلاحية الصفحة. افتحي الرابط من البريد مرة أخرى.' );
		return;
	}
	$user = check_password_reset_key( $key, $login );
	if ( is_wp_error( $user ) ) {
		wp_safe_redirect( atika_page_url( 'login', array( 'action' => 'lost', 'v' => 'rp_expired' ) ) );
		exit;
	}
	$pass  = isset( $_POST['pass1'] ) ? (string) wp_unslash( $_POST['pass1'] ) : ''; // phpcs:ignore
	$pass2 = isset( $_POST['pass2'] ) ? (string) wp_unslash( $_POST['pass2'] ) : ''; // phpcs:ignore
	$prob  = atika_password_problem( $pass, array( strstr( $user->user_email, '@', true ), $user->user_login ) );
	if ( $prob ) {
		atika_err( 'pass1', $prob );
		return;
	}
	if ( $pass !== $pass2 ) {
		atika_err( 'pass2', 'كلمتا المرور غير متطابقتين.' );
		return;
	}
	reset_password( $user, $pass );
	WP_Session_Tokens::get_instance( $user->ID )->destroy_all();
	if ( atika_is_head( $user ) || atika_is_team( $user ) ) {
		$body = '<p>مرحباً ' . esc_html( $user->display_name ) . '،</p><p>تم تعيين كلمة مرور جديدة لحسابك، وتم تسجيل خروجك من جميع الأجهزة الأخرى.</p><p style="color:#7a7f91;font-size:13px">إذا لم تقومي بذلك، تواصلي مع إدارة الموقع فوراً.</p>';
		atika_mail( $user->user_email, 'تم تغيير كلمة المرور | ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'تم تغيير كلمة المرور', $body );
	}
	wp_safe_redirect( atika_page_url( 'login', array( 'v' => 'reset_done' ) ) );
	exit;
}

/* Admin does not need an email every time a head resets her own password. */
remove_action( 'after_password_reset', 'wp_password_change_notification' );

/* Every "forgot password" link on the site opens our own page. */
add_filter( 'lostpassword_url', function () {
	return atika_page_url( 'login', array( 'action' => 'lost' ) );
} );

/* ---------------- Login ---------------- */

function atika_handle_login() {
	if ( ! isset( $_POST['_atika_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_atika_nonce'] ), 'atika_login' ) ) {
		atika_err( 'form', 'انتهت صلاحية الصفحة. حدّثي الصفحة ثم أعيدي المحاولة.' );
		return;
	}
	$login = sanitize_text_field( wp_unslash( isset( $_POST['log'] ) ? $_POST['log'] : '' ) );
	$GLOBALS['atika_form_old'] = array( 'log' => $login );
	if ( ! atika_rate_peek( 'login', 10 ) ) {
		atika_err( 'form', 'محاولات دخول كثيرة. انتظري ١٥ دقيقة ثم حاولي مجدداً.' );
		return;
	}
	$user = wp_signon( array(
		'user_login'    => $login,
		'user_password' => isset( $_POST['pwd'] ) ? (string) wp_unslash( $_POST['pwd'] ) : '', // phpcs:ignore
		'remember'      => ! empty( $_POST['remember'] ),
	), is_ssl() );
	if ( is_wp_error( $user ) ) {
		$code = $user->get_error_code();
		if ( 0 !== strpos( $code, 'atika_' ) ) {
			atika_rate_hit( 'login', 15 * MINUTE_IN_SECONDS ); // only wrong passwords count
		}
		if ( 0 === strpos( $code, 'atika_' ) ) {
			atika_err( 'form', $user->get_error_message() );
			if ( 'atika_unverified' === $code ) {
				$GLOBALS['atika_show_resend'] = true;
			}
		} else {
			atika_err( 'form', 'اسم المستخدم أو كلمة المرور غير صحيحة.' );
		}
		return;
	}
	wp_safe_redirect( atika_page_url( 'dashboard' ) );
	exit;
}

/** Block heads that are not active, wherever they try to log in. */
add_filter( 'authenticate', function ( $user ) {
	if ( ! ( $user instanceof WP_User ) || ! atika_is_head( $user ) ) {
		return $user;
	}
	switch ( atika_head_status( $user->ID ) ) {
		case ATIKA_STATUS_ACTIVE:
			return $user;
		case ATIKA_STATUS_UNVERIFIED:
			return new WP_Error( 'atika_unverified', 'لم تُوثّقي بريدك الإلكتروني بعد. افتحي رسالة التوثيق في بريدك، أو اطلبي رسالة جديدة من الأسفل.' );
		case ATIKA_STATUS_PENDING:
			return new WP_Error( 'atika_pending', 'تم توثيق بريدك، وحسابك بانتظار اعتماد إدارة المدرسة. ستصلك رسالة عند الاعتماد.' );
		default:
			return new WP_Error( 'atika_suspended', 'هذا الحساب موقوف. تواصلي مع إدارة المدرسة.' );
	}
}, 99 );

/* Heads stay on the front end. */
function atika_keep_heads_out_of_admin() {
	if ( is_admin() && ( atika_is_head() || atika_is_team() ) && ! wp_doing_ajax() && ! current_user_can( 'edit_posts' ) ) {
		wp_safe_redirect( atika_page_url( 'dashboard' ) );
		exit;
	}
}
add_action( 'init', 'atika_keep_heads_out_of_admin' );
add_action( 'setup_theme', 'atika_keep_heads_out_of_admin', 0 ); // customize.php refuses access before init.
add_filter( 'show_admin_bar', function ( $show ) {
	return ( atika_is_head() || atika_is_team() ) ? false : $show;
} );
add_filter( 'login_redirect', function ( $redirect, $requested, $user ) {
	return ( $user instanceof WP_User && ( atika_is_head( $user ) || atika_is_team( $user ) ) ) ? atika_page_url( 'dashboard' ) : $redirect;
}, 10, 3 );

/* Use our login page for password-reset flows. */


/* Brand wp-login.php (used for "forgot password"). */
add_action( 'login_enqueue_scripts', function () {
	$logo = esc_url( atika_logo_url() );
	echo '<style>
	body.login{background:#f6f7fa;font-family:"IBM Plex Sans Arabic",Tahoma,sans-serif}
	#login h1 a{background-image:url(' . $logo . ');background-size:contain;width:280px;height:105px}
	.login form{border-radius:12px;border:1px solid #e3e6ee;box-shadow:none}
	.wp-core-ui .button-primary{background:#1b2242;border-color:#1b2242;border-radius:8px}
	.wp-core-ui .button-primary:hover{background:#262f5a;border-color:#262f5a}
	.login #nav a,.login #backtoblog a{color:#1b2242}
	</style>';
} );
add_filter( 'login_headerurl', function () {
	return home_url( '/' );
} );

/* Nobody uses the default WP sign-up form. */
add_filter( 'option_users_can_register', '__return_zero' );

/* ---------------- Cleanup unverified accounts ---------------- */

add_action( 'atika_cleanup_unverified', function () {
	require_once ABSPATH . 'wp-admin/includes/user.php';
	$days  = max( 1, (int) atika_setting( 'cleanup_days' ) );
	$users = get_users( array(
		'role'       => ATIKA_ROLE,
		'meta_key'   => 'atika_status',
		'meta_value' => ATIKA_STATUS_UNVERIFIED,
		'date_query' => array( array( 'before' => $days . ' days ago' ) ),
		'fields'     => array( 'ID' ),
	) );
	foreach ( $users as $u ) {
		wp_delete_user( $u->ID );
	}
} );

/* ======================================================================
 * Shortcodes: register + login
 * ==================================================================== */

function atika_field_error( $field ) {
	$e = $GLOBALS['atika_form_errors'];
	return isset( $e[ $field ] ) ? '<span class="atk-field-err" id="err-' . esc_attr( $field ) . '">' . esc_html( $e[ $field ] ) . '</span>' : '';
}

function atika_auth_shell( $title, $sub, $inner ) {
	return '<div class="atk atk-auth"><div class="atk-auth-card">'
		. '<a class="atk-auth-logo" href="' . esc_url( home_url( '/' ) ) . '"><img src="' . esc_url( atika_logo_url() ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '"></a>'
		. '<h1 class="atk-auth-title">' . esc_html( $title ) . '</h1><p class="atk-auth-sub">' . esc_html( $sub ) . '</p>'
		. $inner . '</div></div>';
}

add_shortcode( 'atika_register', function () {
	if ( ! atika_registration_open() && ! isset( $_GET['registered'] ) ) {
		$inner = '<p class="atk-auth-sub" style="margin-top:0">الدخول إلى لوحة التحكم متاح لأعضاء فريق العمل فقط، بحسابات تُنشئها إدارة الموقع.</p>'
			. '<a class="atk-btn atk-btn-primary atk-btn-block" href="' . esc_url( atika_page_url( 'login' ) ) . '">دخول فريق العمل</a>';
		return atika_auth_shell( 'التسجيل مغلق', 'لا يمكن إنشاء حسابات جديدة من الموقع', $inner );
	}
	if ( is_user_logged_in() ) {
		return atika_auth_shell( 'أنتِ مسجّلة الدخول', 'لا حاجة لإنشاء حساب جديد.', '<a class="atk-btn atk-btn-primary atk-btn-block" href="' . esc_url( atika_page_url( 'dashboard' ) ) . '">الذهاب إلى لوحة التحكم</a>' );
	}
	if ( isset( $_GET['registered'] ) ) {
		$to = isset( $_GET['to'] ) ? sanitize_email( rawurldecode( wp_unslash( $_GET['to'] ) ) ) : '';
		$inner = '<div class="atk-mailsent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>'
			. '<p>أرسلنا رسالة توثيق إلى' . ( $to ? ' <strong dir="ltr">' . esc_html( $to ) . '</strong>' : ' بريدك' ) . '. افتحيها واضغطي زر <strong>توثيق البريد</strong> لإكمال التسجيل.</p>'
			. '<p class="atk-muted">لم تصلك الرسالة؟ تفقّدي مجلد الرسائل غير المرغوب فيها (Spam)، أو اطلبي رسالة جديدة من صفحة الدخول.</p></div>'
			. '<a class="atk-btn atk-btn-ghost atk-btn-block" href="' . esc_url( atika_page_url( 'login' ) ) . '">الذهاب إلى صفحة الدخول</a>';
		return atika_auth_shell( 'تفقّدي بريدك الإلكتروني', 'خطوة أخيرة قبل تفعيل حسابك', $inner );
	}

	$e   = $GLOBALS['atika_form_errors'];
	$f   = function ( $k ) use ( $e ) {
		return isset( $e[ $k ] ) ? ' aria-invalid="true" aria-describedby="err-' . esc_attr( $k ) . '"' : '';
	};
	$approval = atika_setting( 'require_approval' ) ? '<li>تراجع الإدارة الطلب وتعتمده</li>' : '';
	ob_start();
	?>
	<?php echo isset( $e['form'] ) ? atika_notice( esc_html( $e['form'] ) ) : ''; // phpcs:ignore ?>
	<ol class="atk-steps"><li>أنشئي الحساب واكتبي اسم مادتك</li><li>وثّقي بريدك من الرسالة المرسلة</li><?php echo $approval; // phpcs:ignore ?></ol>
	<form method="post" class="atk-form" novalidate>
		<?php wp_nonce_field( 'atika_register', '_atika_nonce' ); ?>
		<input type="hidden" name="atika_action" value="register">
		<div class="atk-hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>

		<label class="atk-field"><span>الاسم الكامل</span>
			<input type="text" name="full_name" id="atk-full-name" value="<?php echo esc_attr( atika_old( 'name' ) ); ?>" required autocomplete="name"<?php echo $f( 'full_name' ); // phpcs:ignore ?>>
			<?php echo atika_field_error( 'full_name' ); // phpcs:ignore ?></label>

		<label class="atk-field"><span>اسم المادة التي ترأسين قسمها</span>
			<input type="text" name="subject" id="atk-subject" value="<?php echo esc_attr( atika_old( 'subject' ) ); ?>" required maxlength="60" placeholder="مثال: اللغة العربية"<?php echo $f( 'subject' ); // phpcs:ignore ?>>
			<small class="atk-hint">تكتبينها كما تريدين أن تظهر في الموقع. لكل مادة رئيسة قسم واحدة.</small>
			<?php echo atika_field_error( 'subject' ); // phpcs:ignore ?></label>

		<div class="atk-row">
			<label class="atk-field"><span>البريد الإلكتروني</span>
				<input type="email" name="email" id="atk-email" dir="ltr" value="<?php echo esc_attr( atika_old( 'email' ) ); ?>" required autocomplete="email"<?php echo $f( 'email' ); // phpcs:ignore ?>>
				<?php echo atika_field_error( 'email' ); // phpcs:ignore ?></label>
			<label class="atk-field"><span>رقم الجوال</span>
				<input type="tel" name="phone" id="atk-phone" dir="ltr" value="<?php echo esc_attr( atika_old( 'phone' ) ); ?>" required autocomplete="tel" inputmode="tel" placeholder="9xxxxxxx" maxlength="15"<?php echo $f( 'phone' ); // phpcs:ignore ?>>
				<?php echo atika_field_error( 'phone' ); // phpcs:ignore ?></label>
		</div>
		<div class="atk-row">
			<label class="atk-field"><span>كلمة المرور</span>
				<input type="password" name="password" id="atk-password" required minlength="8" autocomplete="new-password" data-strength<?php echo $f( 'password' ); // phpcs:ignore ?>>
				<small class="atk-hint">٨ أحرف على الأقل، أحرف وأرقام</small>
				<?php echo atika_field_error( 'password' ); // phpcs:ignore ?></label>
			<label class="atk-field"><span>تأكيد كلمة المرور</span>
				<input type="password" name="password2" id="atk-password2" required autocomplete="new-password"<?php echo $f( 'password2' ); // phpcs:ignore ?>>
				<?php echo atika_field_error( 'password2' ); // phpcs:ignore ?></label>
		</div>
		<label class="atk-check atk-consent"><input type="checkbox" name="consent" id="atk-consent" value="1" required <?php checked( ! empty( $_POST['consent'] ) ); ?>>
			<span>أوافق على <a href="<?php echo esc_url( get_privacy_policy_url() ? get_privacy_policy_url() : home_url( '/privacy-policy/' ) ); ?>" target="_blank" rel="noopener">سياسة الخصوصية</a> واستخدام بياناتي لإدارة حسابي في المنصة.</span></label>
		<?php echo atika_field_error( 'consent' ); // phpcs:ignore ?>
		<button type="submit" class="atk-btn atk-btn-primary atk-btn-block">إنشاء الحساب</button>
	</form>
	<p class="atk-auth-alt">لديكِ حساب؟ <a href="<?php echo esc_url( atika_page_url( 'login' ) ); ?>">سجّلي الدخول</a></p>
	<?php
	return atika_auth_shell( 'تسجيل رئيسة قسم', 'هذا التسجيل مخصص لرئيسات الأقسام فقط', ob_get_clean() );
} );

add_shortcode( 'atika_login', function () {
	$act = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
	if ( 'lost' === $act && ! is_user_logged_in() ) {
		return atika_view_lost();
	}
	if ( 'rp' === $act ) {
		return atika_view_reset();
	}
	if ( is_user_logged_in() ) {
		$u = wp_get_current_user();
		return atika_auth_shell( 'مرحباً ' . $u->display_name, 'أنتِ مسجّلة الدخول بالفعل.', '<a class="atk-btn atk-btn-primary atk-btn-block" href="' . esc_url( atika_page_url( 'dashboard' ) ) . '">الذهاب إلى لوحة التحكم</a><p class="atk-auth-alt"><a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">تسجيل الخروج</a></p>' );
	}
	$msgs = array(
		'ok'         => array( 'success', 'تم توثيق بريدك وتفعيل حسابك. سجّلي الدخول الآن.' ),
		'pending'    => array( 'success', 'تم توثيق بريدك بنجاح. حسابك الآن بانتظار اعتماد إدارة المدرسة، وستصلك رسالة عند الاعتماد.' ),
		'already'    => array( 'info', 'تم توثيق هذا البريد مسبقاً.' ),
		'expired'    => array( 'error', 'انتهت صلاحية رابط التوثيق. اطلبي رابطاً جديداً من الأسفل.' ),
		'invalid'    => array( 'error', 'رابط التوثيق غير صالح. تأكدي من فتح آخر رسالة وصلتك، أو اطلبي رابطاً جديداً.' ),
		'resent'     => array( 'success', 'إذا كان البريد مسجّلاً وغير موثّق، فستصلك رسالة توثيق جديدة خلال دقائق.' ),
		'reset_sent' => array( 'success', 'إذا كان البريد مسجّلاً لدينا فستصلك خلال دقائق رسالة فيها رابط تعيين كلمة مرور جديدة.' ),
		'reset_done' => array( 'success', 'تم تعيين كلمة المرور الجديدة. سجّلي الدخول بها الآن.' ),
	);
	$v    = isset( $_GET['v'] ) ? sanitize_key( $_GET['v'] ) : '';
	$e    = $GLOBALS['atika_form_errors'];
	$show_resend = ! empty( $GLOBALS['atika_show_resend'] ) || in_array( $v, array( 'expired', 'invalid' ), true ) || isset( $e['resend'] );
	ob_start();
	if ( isset( $msgs[ $v ] ) ) {
		echo atika_notice( esc_html( $msgs[ $v ][1] ), $msgs[ $v ][0] ); // phpcs:ignore
	}
	if ( isset( $e['form'] ) ) {
		echo atika_notice( esc_html( $e['form'] ) ); // phpcs:ignore
	}
	?>
	<form method="post" class="atk-form">
		<?php wp_nonce_field( 'atika_login', '_atika_nonce' ); ?>
		<input type="hidden" name="atika_action" value="login">
		<label class="atk-field"><span>اسم المستخدم أو البريد الإلكتروني</span>
			<input type="text" name="log" id="atk-log" dir="ltr" autocapitalize="none" spellcheck="false" value="<?php echo esc_attr( atika_old( 'log' ) ); ?>" required autocomplete="username"></label>
		<label class="atk-field"><span>كلمة المرور</span>
			<input type="password" name="pwd" id="atk-pwd" required autocomplete="current-password"></label>
		<div class="atk-between">
			<label class="atk-check"><input type="checkbox" name="remember" id="atk-remember" value="1"> تذكّريني</label>
			<a href="<?php echo esc_url( atika_page_url( 'login', array( 'action' => 'lost' ) ) ); ?>">نسيتِ كلمة المرور؟</a>
		</div>
		<button type="submit" class="atk-btn atk-btn-primary atk-btn-block">دخول</button>
	</form>
	<?php if ( atika_registration_open() ) : ?>
	<details class="atk-resend" <?php echo $show_resend ? 'open' : ''; ?>>
		<summary>لم تصلك رسالة التوثيق؟</summary>
		<?php echo isset( $e['resend'] ) ? atika_notice( esc_html( $e['resend'] ) ) : ''; // phpcs:ignore ?>
		<form method="post" class="atk-form atk-inline">
			<?php wp_nonce_field( 'atika_resend', '_atika_nonce' ); ?>
			<input type="hidden" name="atika_action" value="resend">
			<input type="email" name="email" id="atk-resend-email" dir="ltr" placeholder="البريد الإلكتروني" required aria-label="البريد الإلكتروني">
			<button type="submit" class="atk-btn atk-btn-ghost">إرسال رابط جديد</button>
		</form>
	</details>
	<p class="atk-auth-alt">رئيسة قسم جديدة؟ <a href="<?php echo esc_url( atika_page_url( 'register' ) ); ?>">أنشئي حسابك</a></p>
	<?php endif; ?>
	<?php
	return atika_registration_open()
		? atika_auth_shell( 'تسجيل الدخول', 'لفريق العمل ورئيسات الأقسام', ob_get_clean() )
		: atika_auth_shell( 'دخول فريق العمل', 'الدخول مخصص لأعضاء فريق عمل المنصة', ob_get_clean() );
} );


/* ---------------- Views: lost + reset ---------------- */

function atika_view_lost() {
	$e = $GLOBALS['atika_form_errors'];
	ob_start();
	if ( isset( $_GET['v'] ) && 'rp_expired' === $_GET['v'] ) {
		echo atika_notice( 'انتهت صلاحية رابط إعادة التعيين أو تم استخدامه من قبل. اطلبي رابطاً جديداً.' ); // phpcs:ignore
	}
	if ( isset( $e['lost'] ) ) {
		echo atika_notice( esc_html( $e['lost'] ) ); // phpcs:ignore
	}
	?>
	<form method="post" class="atk-form">
		<?php wp_nonce_field( 'atika_lost', '_atika_nonce' ); ?>
		<input type="hidden" name="atika_action" value="lost">
		<label class="atk-field"><span>البريد الإلكتروني المسجّل</span>
			<input type="email" name="email" id="atk-lost-email" dir="ltr" value="<?php echo esc_attr( atika_old( 'email' ) ); ?>" required autocomplete="email"></label>
		<button type="submit" class="atk-btn atk-btn-primary atk-btn-block">إرسال رابط إعادة التعيين</button>
	</form>
	<p class="atk-auth-alt"><a href="<?php echo esc_url( atika_page_url( 'login' ) ); ?>">العودة إلى تسجيل الدخول</a></p>
	<?php
	return atika_auth_shell( 'نسيتِ كلمة المرور؟', 'اكتبي بريدك وسنرسل لك رابطاً لتعيين كلمة مرور جديدة', ob_get_clean() );
}

function atika_view_reset() {
	$key   = isset( $_REQUEST['key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['key'] ) ) : ( isset( $_POST['rp_key'] ) ? sanitize_text_field( wp_unslash( $_POST['rp_key'] ) ) : '' );
	$login = isset( $_REQUEST['login'] ) ? sanitize_user( rawurldecode( wp_unslash( $_REQUEST['login'] ) ) ) : ( isset( $_POST['rp_login'] ) ? sanitize_user( wp_unslash( $_POST['rp_login'] ) ) : '' );
	$user  = check_password_reset_key( $key, $login );
	if ( is_wp_error( $user ) ) {
		$inner = atika_notice( 'هذا الرابط منتهي الصلاحية أو تم استخدامه من قبل.' )
			. '<a class="atk-btn atk-btn-primary atk-btn-block" href="' . esc_url( atika_page_url( 'login', array( 'action' => 'lost' ) ) ) . '">طلب رابط جديد</a>';
		return atika_auth_shell( 'رابط غير صالح', 'روابط إعادة التعيين صالحة لمدة ٢٤ ساعة ولمرة واحدة', $inner );
	}
	$e = $GLOBALS['atika_form_errors'];
	$f = function ( $k ) use ( $e ) {
		return isset( $e[ $k ] ) ? ' aria-invalid="true" aria-describedby="err-' . esc_attr( $k ) . '"' : '';
	};
	ob_start();
	if ( isset( $e['form'] ) ) {
		echo atika_notice( esc_html( $e['form'] ) ); // phpcs:ignore
	}
	?>
	<form method="post" class="atk-form">
		<?php wp_nonce_field( 'atika_resetpass', '_atika_nonce' ); ?>
		<input type="hidden" name="atika_action" value="resetpass">
		<input type="hidden" name="rp_key" value="<?php echo esc_attr( $key ); ?>">
		<input type="hidden" name="rp_login" value="<?php echo esc_attr( $login ); ?>">
		<input type="text" name="username" value="<?php echo esc_attr( $user->user_email ); ?>" autocomplete="username" hidden>
		<label class="atk-field"><span>كلمة المرور الجديدة</span>
			<input type="password" name="pass1" id="atk-pass1" required minlength="8" autocomplete="new-password" data-strength<?php echo $f( 'pass1' ); // phpcs:ignore ?>>
			<small class="atk-hint">٨ أحرف على الأقل، أحرف وأرقام</small>
			<?php echo atika_field_error( 'pass1' ); // phpcs:ignore ?></label>
		<label class="atk-field"><span>تأكيد كلمة المرور</span>
			<input type="password" name="pass2" id="atk-pass2" required autocomplete="new-password"<?php echo $f( 'pass2' ); // phpcs:ignore ?>>
			<?php echo atika_field_error( 'pass2' ); // phpcs:ignore ?></label>
		<button type="submit" class="atk-btn atk-btn-primary atk-btn-block">حفظ كلمة المرور</button>
	</form>
	<?php
	return atika_auth_shell( 'تعيين كلمة مرور جديدة', 'للحساب: ' . $user->user_email, ob_get_clean() );
}
