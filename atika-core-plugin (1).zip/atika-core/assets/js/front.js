(function () {
  'use strict';
  var cfg = window.ATIKA || { maxImages: 10, maxMb: 5 };

  // Confirm before destructive actions.
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.dataset && f.dataset.confirm && !window.confirm(f.dataset.confirm)) {
      e.preventDefault();
    }
  }, true);

  // Show / hide password + strength meter.
  Array.prototype.forEach.call(document.querySelectorAll('.atk input[type=password]'), function (inp) {
    var wrap = document.createElement('div');
    wrap.className = 'atk-pw';
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'atk-pw-toggle';
    b.setAttribute('aria-label', 'إظهار كلمة المرور');
    b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
    b.addEventListener('click', function () {
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      b.classList.toggle('on', show);
      b.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
    });
    wrap.appendChild(b);
    if (inp.hasAttribute('data-strength')) {
      var m = document.createElement('div');
      m.className = 'atk-meter';
      m.innerHTML = '<span></span><em></em>';
      wrap.parentNode.insertBefore(m, wrap.nextSibling);
      var labels = ['', 'ضعيفة', 'متوسطة', 'جيدة', 'قوية'];
      inp.addEventListener('input', function () {
        var v = inp.value, sc = 0;
        if (v.length >= 8) sc++;
        if (/\d/.test(v) && /\D/.test(v)) sc++;
        if (v.length >= 12) sc++;
        if (/[^\w\s]/.test(v) || (/[a-z]/.test(v) && /[A-Z]/.test(v))) sc++;
        if (v.length < 8) sc = Math.min(sc, 1);
        m.dataset.s = v ? sc : 0;
        m.querySelector('em').textContent = v ? labels[Math.max(1, sc)] : '';
      });
    }
  });

  var input = document.getElementById('atk-images');
  var form = document.getElementById('atk-ach-form');
  if (!input || !form) return;

  var drop = document.getElementById('atk-drop');
  var previews = document.getElementById('atk-previews');
  var existing = parseInt(input.dataset.existing || '0', 10);
  var busy = false;
  var canReplace = typeof DataTransfer !== 'undefined';

  function ar(n) { return String(n).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'[d]; }); }

  // Shrink large phone photos in the browser so uploads stay fast and under hosting limits.
  function shrink(file) {
    return new Promise(function (resolve) {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 1.2 * 1024 * 1024) return resolve(file);
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        var max = 2000, w = img.naturalWidth, h = img.naturalHeight, s = Math.min(1, max / Math.max(w, h));
        var c = document.createElement('canvas');
        c.width = Math.round(w * s); c.height = Math.round(h * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        c.toBlob(function (b) {
          if (!b || b.size >= file.size) return resolve(file);
          resolve(new File([b], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg', lastModified: Date.now() }));
        }, 'image/jpeg', 0.85);
      };
      img.onerror = function () { URL.revokeObjectURL(url); resolve(file); };
      img.src = url;
    });
  }

  function render(files) {
    previews.innerHTML = '';
    var removed = form.querySelectorAll('input[name="remove_images[]"]:checked').length;
    var room = cfg.maxImages - (existing - removed);
    Array.prototype.forEach.call(files, function (f, i) {
      var fig = document.createElement('figure');
      var bad = f.size > cfg.maxMb * 1024 * 1024 || i >= room;
      if (bad) fig.className = 'bad';
      if (/^image\//.test(f.type)) {
        var im = document.createElement('img');
        im.alt = '';
        im.src = URL.createObjectURL(f);
        im.onload = function () { URL.revokeObjectURL(im.src); };
        fig.appendChild(im);
      }
      var cap = document.createElement('figcaption');
      cap.textContent = i >= room ? 'تجاوز العدد' : (f.size > cfg.maxMb * 1024 * 1024 ? 'حجم كبير' : (f.size / 1048576).toFixed(1) + ' MB');
      fig.appendChild(cap);
      previews.appendChild(fig);
    });
  }

  function handle(fileList) {
    var list = Array.prototype.slice.call(fileList).filter(function (f) { return /^image\//.test(f.type) || /\.heic$/i.test(f.name); });
    if (!canReplace) { render(input.files); return; }
    busy = true;
    drop.querySelector('strong').textContent = 'جاري تجهيز الصور…';
    Promise.all(list.map(shrink)).then(function (out) {
      var dt = new DataTransfer();
      out.forEach(function (f) { dt.items.add(f); });
      input.files = dt.files;
      render(input.files);
      drop.querySelector('strong').textContent = out.length ? ('تم اختيار ' + ar(out.length) + ' صور، اضغطي لتغييرها') : 'اسحبي الصور هنا أو اضغطي للاختيار';
      busy = false;
    });
  }

  input.addEventListener('change', function () { handle(input.files); });
  ['dragenter', 'dragover'].forEach(function (t) {
    drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.add('over'); });
  });
  ['dragleave', 'drop'].forEach(function (t) {
    drop.addEventListener(t, function () { drop.classList.remove('over'); });
  });
  drop.addEventListener('drop', function (e) {
    e.preventDefault();
    if (e.dataTransfer && e.dataTransfer.files.length) handle(e.dataTransfer.files);
  });
  form.addEventListener('change', function (e) {
    if (e.target.name === 'remove_images[]' && input.files.length) render(input.files);
  });

  form.addEventListener('submit', function (e) {
    if (busy) { e.preventDefault(); return; }
    if (previews.querySelector('figure.bad')) {
      e.preventDefault();
      previews.scrollIntoView({ block: 'center' });
      window.alert('بعض الصور المؤشرة بالأحمر أكبر من الحجم المسموح أو تتجاوز عدد الصور. احذفيها أو اختاري صوراً أخرى.');
      return;
    }
    var btn = document.getElementById('atk-save');
    if (btn) { btn.disabled = true; btn.textContent = input.files.length ? 'جاري رفع الصور والحفظ…' : 'جاري الحفظ…'; }
  });
})();
